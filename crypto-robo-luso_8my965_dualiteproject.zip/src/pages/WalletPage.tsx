import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { getWalletSummary, getInvestments, getTransactionHistory } from "@/services/walletService";

import { UserBalance } from "@/components/UserBalance";
import { UserInvestments } from "@/components/UserInvestments";
import { WithdrawDialog } from "@/components/WithdrawDialog";
import { TransactionHistory } from "@/components/TransactionHistory";
import { Skeleton } from "@/components/ui/skeleton";
import { Card } from "@/components/ui/card";

const WalletPage = () => {
  const { user, loading: authLoading } = useAuth();
  const [showWithdraw, setShowWithdraw] = useState(false);
  const queryClient = useQueryClient();

  const { data: summary, isLoading: summaryLoading } = useQuery({
    queryKey: ['walletSummary', user?.id],
    queryFn: () => getWalletSummary(user!.id),
    enabled: !!user,
  });

  const { data: investments, isLoading: investmentsLoading } = useQuery({
    queryKey: ['investments', user?.id],
    queryFn: () => getInvestments(user!.id),
    enabled: !!user,
  });

  const { data: transactions, isLoading: transactionsLoading } = useQuery({
    queryKey: ['transactions', user?.id],
    queryFn: () => getTransactionHistory(user!.id),
    enabled: !!user,
  });
  
  const isLoading = authLoading || summaryLoading || investmentsLoading || transactionsLoading;

  const totalProfit = investments?.reduce((sum, inv) => sum + inv.currentProfit, 0) || 0;

  const handleWithdrawSuccess = () => {
    queryClient.invalidateQueries({ queryKey: ['walletSummary', user?.id] });
    queryClient.invalidateQueries({ queryKey: ['transactions', user?.id] });
  }

  return (
    <div className="space-y-6">
      {isLoading ? (
        <Skeleton className="h-20 w-full" />
      ) : (
        <Card className="p-4 bg-secondary/50">
          <h2 className="text-xl font-semibold">Olá, {summary?.fullName?.split(' ')[0]}!</h2>
          <p className="text-sm text-muted-foreground">
            Membro desde {new Date(summary?.createdAt ?? '').toLocaleDateString('pt-BR')}
          </p>
        </Card>
      )}

      {isLoading ? (
        <Skeleton className="h-64 w-full" />
      ) : (
        <UserBalance 
          balance={summary?.balance ?? 0}
          totalInvested={summary?.totalInvested ?? 0}
          totalProfit={totalProfit}
          onWithdraw={() => setShowWithdraw(true)}
          hasInvestment={(investments?.length ?? 0) > 0}
        />
      )}

      {isLoading ? (
        <div className="space-y-4">
          <Skeleton className="h-40 w-full" />
          <Skeleton className="h-40 w-full" />
        </div>
      ) : (
        <UserInvestments investments={investments ?? []} />
      )}
      
      {isLoading ? (
        <Skeleton className="h-80 w-full" />
      ) : (
        <TransactionHistory transactions={transactions ?? []} />
      )}

      <WithdrawDialog 
        open={showWithdraw}
        onOpenChange={setShowWithdraw}
        availableBalance={summary?.balance ?? 0}
        onSuccess={handleWithdrawSuccess}
      />
    </div>
  );
};

export default WalletPage;
