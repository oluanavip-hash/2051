import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { WalletDepositModal } from "./WalletDepositModal";
import { useToast } from "@/hooks/use-toast";

interface UserBalanceProps {
  balance: number;
  totalInvested: number;
  totalProfit: number;
  onWithdraw: () => void;
  hasInvestment: boolean;
}

export const UserBalance = ({ balance, totalInvested, totalProfit, onWithdraw, hasInvestment }: UserBalanceProps) => {
  const [showDepositModal, setShowDepositModal] = useState(false);
  const { toast } = useToast();

  const handleWithdrawClick = () => {
    if (!hasInvestment) {
      toast({
        title: "Saque Indisponível",
        description: "É necessário realizar um investimento antes de sacar.",
        variant: "destructive"
      });
      return;
    }
    onWithdraw();
  };

  return (
    <Card className="p-4 space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="text-center p-3 bg-secondary rounded-lg">
          <p className="text-sm text-muted-foreground">Saldo Disponível</p>
          <p className="text-xl font-bold text-foreground">R$ {balance.toFixed(2)}</p>
        </div>
        
        <div className="text-center p-3 bg-secondary rounded-lg">
          <p className="text-sm text-muted-foreground">Total Investido</p>
          <p className="text-xl font-bold text-foreground">R$ {totalInvested.toFixed(2)}</p>
        </div>
      </div>

      <div className="text-center p-3 bg-primary/10 rounded-lg border border-primary/20">
        <p className="text-sm text-muted-foreground">Lucros Acumulados</p>
        <p className="text-2xl font-bold text-primary">R$ {totalProfit.toFixed(2)}</p>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <Button 
          variant="outline" 
          onClick={() => setShowDepositModal(true)}
        >
          Depositar
        </Button>
        <Button 
          variant="default" 
          onClick={handleWithdrawClick}
        >
          Sacar
        </Button>
      </div>

      <WalletDepositModal 
        open={showDepositModal}
        onOpenChange={setShowDepositModal}
      />
    </Card>
  );
};
