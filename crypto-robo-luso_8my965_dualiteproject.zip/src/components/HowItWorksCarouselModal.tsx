import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious, type CarouselApi } from "@/components/ui/carousel";
import { Card, CardContent } from "@/components/ui/card";

interface HowItWorksCarouselModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const slides = [
  {
    image: "https://i.ibb.co/dswbXFfj/Design-sem-nome-20251001-154456-0000.png",
    description: (
      <>
        Imagine <span className="text-primary text-glow">robôs inteligentes</span> minerando as <span className="text-primary text-glow">memecoins mais lucrativas</span> para você <span className="text-primary text-glow">24 horas por dia</span>. Apresentamos o <span className="text-primary text-glow">Cripto iMiner</span>, a <span className="text-primary text-glow">plataforma revolucionária</span> onde você investe e nossa <span className="text-primary text-glow">inteligência artificial especializada</span> faz todo o trabalho.
      </>
    ),
  },
  {
    image: "https://i.ibb.co/JR9ZBCKr/Design-sem-nome-20251001-151559-0000.png",
    description: (
      <>
        Nossos robôs <span className="text-primary text-glow">analisam padrões gráficos</span> com <span className="text-primary text-glow">precisão extraordinária</span>, identificando as <span className="text-primary text-glow">melhores oportunidades</span> no mercado de memecoins.
      </>
    ),
  },
  {
    image: "https://i.ibb.co/fdjCQj46/Design-sem-nome-20251001-151512-0000.png",
    description: (
      <>
        Eles <span className="text-primary text-glow">operam automaticamente</span>, comprando e vendendo no <span className="text-primary text-glow">momento exato</span> para <span className="text-primary text-glow">maximizar seus lucros</span>.
      </>
    ),
  },
  {
    image: "https://i.ibb.co/x83CtFKM/Design-sem-nome-20251001-151656-0000.png",
    description: (
      <>
        E os resultados? Retornos que podem chegar a até <span className="text-primary text-glow">600% em médio prazo</span>. <span className="text-primary text-glow">Sem complicação</span>, sem precisar entender de criptomoedas.
      </>
    ),
  },
  {
    image: "https://i.ibb.co/d41yd43j/Design-sem-nome-20251001-151306-0000.png",
    description: (
      <>
        Você apenas <span className="text-primary text-glow">investe</span> e nossa <span className="text-primary text-glow">tecnologia faz o resto</span>. Esta é a <span className="text-primary text-glow">nova era</span> dos <span className="text-primary text-glow">investimentos inteligentes</span> em criptomoedas. Acesse agora e <span className="text-primary text-glow">transforme seu futuro financeiro</span>. <br /><br /> <span className="text-yellow-400/80 text-xs">⚠ Investimentos envolvem riscos, resultados passados não garantem retornos futuros.</span>
      </>
    ),
  },
];

export function HowItWorksCarouselModal({ open, onOpenChange }: HowItWorksCarouselModalProps) {
  const [api, setApi] = useState<CarouselApi>();
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    if (!api) return;
    setCurrent(api.selectedScrollSnap() + 1);
    api.on("select", () => {
      setCurrent(api.selectedScrollSnap() + 1);
    });
  }, [api]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl w-[95vw] bg-card text-white border-border p-0 flex flex-col max-h-[95vh]">
        <DialogHeader className="p-6 pb-2 text-center border-b border-border/50">
          <DialogTitle className="text-2xl font-bold text-primary text-glow">Como Funciona</DialogTitle>
          <DialogDescription>Um guia passo a passo sobre nossa plataforma.</DialogDescription>
        </DialogHeader>
        <div className="flex-1 min-h-0 py-4">
          <Carousel setApi={setApi} className="w-full h-full flex flex-col justify-center">
            <CarouselContent>
              {slides.map((slide, index) => (
                <CarouselItem key={index}>
                  <div className="p-1 h-full">
                    <Card className="border-0 bg-transparent shadow-none h-full">
                      <CardContent className="flex flex-col items-center justify-center p-4 md:p-6 space-y-4 h-full">
                        <img src={slide.image} alt={`Passo ${index + 1}`} className="rounded-lg w-full h-auto object-contain max-h-[50vh]" />
                        <p className="text-center text-muted-foreground text-sm md:text-base">{slide.description}</p>
                      </CardContent>
                    </Card>
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/30 text-white border-white/20 hover:bg-black/50" />
            <CarouselNext className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/30 text-white border-white/20 hover:bg-black/50" />
          </Carousel>
        </div>
        <div className="flex justify-center gap-2 pb-4">
          {slides.map((_, index) => (
            <div
              key={index}
              className={`h-2 w-2 rounded-full transition-all ${current === index + 1 ? "w-4 bg-primary" : "bg-muted-foreground/50"}`}
            />
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
