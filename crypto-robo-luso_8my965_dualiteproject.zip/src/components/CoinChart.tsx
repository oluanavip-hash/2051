import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { MemeCoin } from "./CoinSelector";
import { supabase } from "@/integrations/supabase/client";
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer } from 'recharts';

interface CoinChartProps {
  coin: MemeCoin;
}

export const CoinChart = ({ coin }: CoinChartProps) => {
  const [coinData, setCoinData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCoinData = async () => {
      setLoading(true);
      try {
        const { data, error } = await supabase.functions.invoke('coindesk-api', {
          body: { coinId: coin.id }
        });

        if (error) throw error;
        setCoinData(data);
      } catch (error) {
        console.error('Erro ao buscar dados da moeda:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchCoinData();
    const interval = setInterval(fetchCoinData, 60000); // Update every minute

    return () => clearInterval(interval);
  }, [coin.id]);

  if (loading) {
    return (
      <Card className="p-4 mt-3">
        <div className="flex items-center space-x-2 mb-3">
          <img src={coin.icon} alt={coin.name} className="w-6 h-6" />
          <h4 className="font-semibold">{coin.name} ({coin.symbol})</h4>
        </div>
        <div className="h-32 bg-secondary/50 rounded-lg flex items-center justify-center">
          <div className="text-center text-muted-foreground">
            <div className="text-2xl mb-1">⏳</div>
            <p className="text-sm">Carregando dados...</p>
          </div>
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-4 mt-3">
      <div className="flex items-center space-x-2 mb-3">
        <img src={coin.icon} alt={coin.name} className="w-6 h-6" />
        <h4 className="font-semibold">{coin.name} ({coin.symbol})</h4>
      </div>
      
      {coinData?.chartData && (
        <div className="h-32 mb-3">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={coinData.chartData}>
              <XAxis hide />
              <YAxis hide />
              <Line 
                type="monotone" 
                dataKey="price" 
                stroke="hsl(var(--primary))" 
                strokeWidth={2}
                dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
      
      <div className="grid grid-cols-2 gap-4 text-sm">
        <div className="text-center">
          <span className="text-muted-foreground">Preço Atual:</span>
          <p className="font-semibold text-primary">
            R$ {coinData?.currentPrice ? parseFloat(coinData.currentPrice).toFixed(6) : '--'}
          </p>
        </div>
        <div className="text-center">
          <span className="text-muted-foreground">24h:</span>
          <p className={`font-semibold ${coinData?.change24h >= 0 ? 'text-green-500' : 'text-red-500'}`}>
            {coinData?.change24h ? `${coinData.change24h > 0 ? '+' : ''}${parseFloat(coinData.change24h).toFixed(2)}%` : '--'}
          </p>
        </div>
      </div>
    </Card>
  );
};
