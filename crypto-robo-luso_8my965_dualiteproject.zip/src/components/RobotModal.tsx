import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { purchaseRobot } from "@/services/walletService";
import { useToast } from "@/hooks/use-toast";

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { ComposedChart, Line, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { TrendingUp, DollarSign, Calendar, AlertCircle } from "lucide-react";
import { CoinSelector } from "./CoinSelector";
import { CoinChart } from "./CoinChart";
import { Robot } from "@/data/robots";
import { MemeCoin } from "@/data/coins";
import { ScrollArea } from "./ui/scroll-area";

interface RobotModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  robot: Robot | null;
}

export const RobotModal = ({ open, onOpenChange, robot }: RobotModalProps) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [investmentAmount, setInvestmentAmount] = useState("");
  const [selectedCoin, setSelectedCoin] = useState<MemeCoin | null>(null);

  const purchaseMutation = useMutation({
    mutationFn: ({ amount, period, coinId }: { amount: number; period: number; coinId: string }) => {
      if (!user || !robot) throw new Error("Usuário ou robô não encontrado");
      return purchaseRobot(user.id, robot.id, amount, period, coinId);
    },
    onSuccess: (data) => {
      toast({
        title: "Investimento Realizado!",
        description: data.message,
      });
      queryClient.invalidateQueries({ queryKey: ['walletSummary', user?.id] });
      queryClient.invalidateQueries({ queryKey: ['investments', user?.id] });
      queryClient.invalidateQueries({ queryKey: ['transactions', user?.id] });
      onOpenChange(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao Investir",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  if (!robot) return null;

  const handlePurchase = () => {
    const amount = parseFloat(investmentAmount);
    if (!selectedCoin) {
      toast({
        title: "Dados Inválidos",
        description: "Por favor, selecione uma moeda para minerar.",
        variant: "destructive",
      });
      return;
    }
    if (isNaN(amount) || amount < robot.minInvestment || amount > robot.maxInvestment) {
      toast({
        title: "Dados Inválidos",
        description: "Por favor, insira um valor de investimento válido.",
        variant: "destructive",
      });
      return;
    }
    purchaseMutation.mutate({ amount, period: robot.period, coinId: selectedCoin.id });
  };
  
  const transactionFeeRate = robot.transactionFee;

  const generateProjectionData = (baseInvestment: number) => {
    if (!robot) return [];

    const data = [];
    const days = robot.period;

    const netInvestment = baseInvestment * (1 - transactionFeeRate);
    const totalProfit = netInvestment * (robot.totalReturn / 100);
    const profitPerDay = days > 0 ? totalProfit / days : totalProfit;

    for (let i = 0; i <= days; i++) {
        const currentProfit = profitPerDay * i;
        const currentValue = netInvestment + currentProfit;

        if (i === 0 || i % Math.ceil(days / 5) === 0 || i === days) {
             data.push({
                day: `Dia ${i}`,
                profit: parseFloat(currentProfit.toFixed(2)),
                total: parseFloat(currentValue.toFixed(2))
             });
        }
    }
    
    const lastDayData = data.find(d => d.day === `Dia ${days}`);
    const finalDataPoint = {
        day: `Dia ${days}`,
        profit: parseFloat(totalProfit.toFixed(2)),
        total: parseFloat((netInvestment + totalProfit).toFixed(2))
    };

    if (!lastDayData) {
        data.push(finalDataPoint);
    } else {
        const lastDayIndex = data.findIndex(d => d.day === `Dia ${days}`);
        data[lastDayIndex] = finalDataPoint;
    }

    return data;
  };

  const projectionData = generateProjectionData(robot.minInvestment);
  
  const amount = parseFloat(investmentAmount);
  const transactionFee = isNaN(amount) ? 0 : amount * transactionFeeRate;
  const netInvestment = isNaN(amount) ? 0 : amount - transactionFee;
  const profit = isNaN(amount) ? 0 : netInvestment * (robot.totalReturn / 100);
  const total = isNaN(amount) ? 0 : amount + profit;

  return (
    <Dialog open={open} onOpenChange={(isOpen) => {
      if (!isOpen) {
        setInvestmentAmount("");
        setSelectedCoin(null);
      }
      onOpenChange(isOpen);
    }}>
      <DialogContent className="sm:max-w-md w-[95vw] bg-card text-white border-border max-h-[90vh] flex flex-col p-0">
        <DialogHeader className="p-4 md:p-6 pb-4 border-b border-border flex-shrink-0">
          <div className="flex items-start gap-4">
            <img src={robot.icon} alt={robot.name} className="w-12 h-12 md:w-16 md:h-16" />
            <div>
              <DialogTitle className="text-xl md:text-2xl">{robot.name}</DialogTitle>
              <DialogDescription>{robot.description}</DialogDescription>
            </div>
          </div>
        </DialogHeader>
        
        <ScrollArea className="flex-1">
          <div className="p-4 md:p-6 space-y-4">
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-background rounded-lg p-3 text-center">
                <TrendingUp className="w-5 h-5 text-primary mx-auto mb-1" />
                <div className="text-xs text-muted-foreground">Retorno Total</div>
                <div className="text-lg font-bold text-primary">{robot.totalReturn}%</div>
              </div>
              <div className="bg-background rounded-lg p-3 text-center">
                <Calendar className="w-5 h-5 text-muted-foreground mx-auto mb-1" />
                <div className="text-xs text-muted-foreground">Período</div>
                <div className="text-lg font-bold">{robot.period} dias</div>
              </div>
              <div className="bg-background rounded-lg p-3 text-center">
                <DollarSign className="w-5 h-5 text-yellow-400 mx-auto mb-1" />
                <div className="text-xs text-muted-foreground">Diário</div>
                <div className="text-lg font-bold">~{robot.dailyReturn.toFixed(2)}%</div>
              </div>
            </div>

            <div className="bg-background rounded-lg p-4">
              <h3 className="text-lg font-semibold mb-4">Projeção de Ganhos (Base R$ {robot.minInvestment})</h3>
              <ResponsiveContainer width="100%" height={150}>
                <ComposedChart data={projectionData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="day" 
                    stroke="hsl(var(--muted-foreground))" 
                    fontSize={9} 
                    interval="preserveStartEnd"
                    tickMargin={5}
                  />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={9} />
                  <Tooltip contentStyle={{ backgroundColor: 'hsl(var(--background))', border: '1px solid hsl(var(--border))' }} />
                  <Legend wrapperStyle={{ fontSize: '10px' }} />
                  <Bar dataKey="profit" fill="hsl(var(--primary))" name="Lucro" />
                  <Line type="monotone" dataKey="total" stroke="hsl(var(--primary))" strokeWidth={2} name="Total" dot={false} />
                </ComposedChart>
              </ResponsiveContainer>
            </div>

            <div className="bg-background rounded-lg p-4">
              <CoinSelector onSelect={setSelectedCoin} selectedCoin={selectedCoin || undefined} />
              {selectedCoin && <CoinChart coin={selectedCoin} />}
            </div>

            <div className="bg-background/50 border border-border rounded-lg p-4">
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-primary" />
                Comprar Ativo
              </h3>
              
              <div className="space-y-4">
                <div>
                  <Label htmlFor="investment" className="text-gray-300">
                    Valor do investimento (Mín: R${robot.minInvestment}, Máx: R${robot.maxInvestment})
                  </Label>
                  <Input
                    id="investment"
                    type="number"
                    placeholder={`R$ ${robot.minInvestment}`}
                    value={investmentAmount}
                    onChange={(e) => setInvestmentAmount(e.target.value)}
                    className="bg-card border-border text-white mt-2"
                    min={robot.minInvestment}
                    max={robot.maxInvestment}
                  />
                </div>

                {amount >= robot.minInvestment && amount <= robot.maxInvestment && (
                  <div className="bg-card rounded-lg p-4 space-y-2 border border-primary/20">
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-muted-foreground">Valor Bruto:</span>
                      <span className="font-semibold">R$ {amount.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-muted-foreground">Taxa ({(transactionFeeRate * 100).toFixed(0)}%):</span>
                      <span className="font-semibold text-red-400">- R$ {transactionFee.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-muted-foreground">Valor Líquido:</span>
                      <span className="font-semibold">R$ {netInvestment.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-muted-foreground">Lucro Estimado:</span>
                      <span className="font-semibold text-primary">+ R$ {profit.toFixed(2)}</span>
                    </div>
                    <div className="h-px bg-border my-2"></div>
                    <div className="flex justify-between items-center">
                      <span className="font-semibold">Retorno total:</span>
                      <span className="text-xl font-bold">R$ {total.toFixed(2)}</span>
                    </div>
                  </div>
                )}

                <div className="bg-yellow-900/50 text-yellow-300 text-xs p-3 rounded-md flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                  <span>Selecione a moeda que você deseja minerar antes de comprar o ativo.</span>
                </div>

                <Button 
                  onClick={handlePurchase}
                  disabled={!selectedCoin || !investmentAmount || amount < robot.minInvestment || amount > robot.maxInvestment || purchaseMutation.isPending}
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
                >
                  {purchaseMutation.isPending ? "Processando..." : "Comprar Ativo"}
                </Button>
              </div>
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
};
