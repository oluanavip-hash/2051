import { Button } from "@/components/ui/button";
import { memeCoins, MemeCoin } from "@/data/coins";

interface CoinSelectorProps {
  onSelect: (coin: MemeCoin) => void;
  selectedCoin?: MemeCoin;
}

export const CoinSelector = ({ onSelect, selectedCoin }: CoinSelectorProps) => {
  return (
    <div className="space-y-3">
      <h4 className="text-sm font-medium">Escolha a Memecoin para Minerar:</h4>
      <div className="relative overflow-x-auto pb-2">
        <div className="flex gap-2 min-w-max">
          {memeCoins.map((coin) => (
            <Button
              key={coin.id}
              variant={selectedCoin?.id === coin.id ? "default" : "outline"}
              size="sm"
              onClick={() => onSelect(coin)}
              className="text-xs h-auto py-2 px-3 flex-shrink-0"
            >
              <div className="text-center w-12">
                <img src={coin.icon} alt={coin.name} className="w-8 h-8 mx-auto mb-1" />
                <div className="font-semibold truncate">{coin.symbol}</div>
              </div>
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
};
