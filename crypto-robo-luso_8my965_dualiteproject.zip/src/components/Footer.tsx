export const Footer = () => {
  return (
    <footer className="w-full mt-12 py-6 px-4 border-t border-border/20 text-center text-xs text-muted-foreground">
      <div className="max-w-4xl mx-auto space-y-2">
        <p>MYNT CRYPTO TECNOLOGIA LTDA. | CNPJ 44.364.466/0001-41</p>
        <p>Av. Brigadeiro Faria Lima, 3447, 9º andar - sala 11 - Itaim Bibi - São Paulo, SP, 04538-133</p>
        <p className="pt-2 opacity-70">© 2025 CryptoAI Miner. Todos os direitos reservados.</p>
      </div>
    </footer>
  );
};
