import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "./ui/button";
import { useToast } from "@/hooks/use-toast";

interface PrizeInfo {
  imageUrl: string;
  description: string;
}

interface AchievementPrizeModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  prizeInfo: {
    prize: PrizeInfo;
    name: string;
    isCompleted: boolean;
  } | null;
}

export const AchievementPrizeModal = ({ open, onOpenChange, prizeInfo }: AchievementPrizeModalProps) => {
  const { toast } = useToast();
  
  if (!prizeInfo) return null;

  const handleClaim = () => {
    toast({
      title: "Solicitação Enviada!",
      description: `Sua solicitação para o prêmio ${prizeInfo.name} foi enviada. Nossa equipe entrará em contato.`,
    });
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md max-h-[90vh] flex flex-col p-0">
        <DialogHeader className="p-6 pb-4 border-b">
          <DialogTitle>Prêmio Conquista: {prizeInfo.name}</DialogTitle>
          <DialogDescription>{prizeInfo.prize.description}</DialogDescription>
        </DialogHeader>
        <ScrollArea className="flex-1 min-h-0">
          <div className="p-6 pt-2 space-y-4">
            <img 
              src={prizeInfo.prize.imageUrl} 
              alt={`Prêmio ${prizeInfo.name}`}
              className="w-full h-auto rounded-lg object-cover border"
            />
            <div className="text-center bg-primary/10 p-4 rounded-lg border border-primary/20">
              <p className="text-lg font-bold text-primary">{prizeInfo.prize.description}</p>
            </div>
          </div>
        </ScrollArea>
        <DialogFooter className="p-6 pt-4 border-t">
          {prizeInfo.isCompleted ? (
            <Button className="w-full" onClick={handleClaim}>Solicitar Prêmio</Button>
          ) : (
            <Button className="w-full" disabled>Continue progredindo para resgatar</Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
