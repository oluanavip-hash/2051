import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Investment } from "@/services/walletService";
import { Progress } from "@/components/ui/progress";
import { robots as robotDetails, Robot } from "@/data/robots";
import { memeCoins } from "@/data/coins";
import { Separator } from "@/components/ui/separator";

interface UserInvestmentsProps {
  investments: Investment[];
}

const getRobotDetails = (robotId: string): Robot | undefined => {
  return robotDetails.find(r => r.id === robotId);
}

export const UserInvestments = ({ investments }: UserInvestmentsProps) => {
  if (investments.length === 0) {
    return (
      <div className="space-y-4">
        <h2 className="text-lg font-semibold">Meus Investimentos</h2>
        <Card className="p-4 text-center text-muted-foreground">
          Você ainda não possui investimentos ativos.
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-semibold">Meus Investimentos</h2>
      
      {investments.map((investment) => {
        const robot = getRobotDetails(investment.robotId);
        const coin = memeCoins.find(c => c.id === investment.coinId);
        let finalReturn = 0;
        if (robot) {
          const netInvestment = investment.amount * (1 - robot.transactionFee);
          const totalProfit = netInvestment * (robot.totalReturn / 100);
          finalReturn = investment.amount + totalProfit;
        }

        return (
          <Card key={investment.id} className="p-4 space-y-3">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-semibold">{investment.robotName}</h3>
                <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                  {coin && (
                    <div className="flex items-center gap-1.5">
                      <img src={coin.icon} alt={coin.name} className="w-4 h-4" />
                      <span>{coin.symbol}</span>
                      <Separator orientation="vertical" className="h-4 bg-border" />
                    </div>
                  )}
                  <span>
                    Investido em {investment.startDate.toLocaleDateString('pt-BR')}
                  </span>
                </div>
              </div>
              <Badge variant={investment.canWithdraw ? "default" : "secondary"}>
                {investment.daysRemaining > 0 ? `${investment.daysRemaining} dias restantes` : "Finalizado"}
              </Badge>
            </div>

            <div className="grid grid-cols-3 gap-4 text-sm">
              <div className="text-center">
                <p className="text-muted-foreground">Investido</p>
                <p className="font-semibold">R$ {investment.amount.toFixed(2)}</p>
              </div>
              <div className="text-center">
                <p className="text-muted-foreground">Lucro Atual</p>
                <p className="font-semibold text-primary">R$ {investment.currentProfit.toFixed(2)}</p>
              </div>
              <div className="text-center">
                <p className="text-muted-foreground">Retorno Final</p>
                <p className="font-semibold text-primary">R$ {finalReturn.toFixed(2)}</p>
              </div>
            </div>

            <Progress value={investment.progress} className="h-2" />

            <div className="flex justify-between text-xs text-muted-foreground">
              <span>Progresso: {Math.round(investment.progress)}%</span>
              <span>
                {investment.canWithdraw ? "Disponível para saque" : `Libera em ${investment.endDate.toLocaleDateString('pt-BR')}`}
              </span>
            </div>
          </Card>
        );
      })}
    </div>
  );
};
