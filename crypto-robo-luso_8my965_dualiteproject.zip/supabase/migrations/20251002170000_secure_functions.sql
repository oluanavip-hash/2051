/*
# [SECURITY] Secure Database Functions
This script updates existing database functions to mitigate security warnings by setting a fixed search_path. This prevents potential hijacking attacks.

## Query Description:
- This operation modifies the definition of three functions: `handle_new_user`, `handle_first_deposit`, and `purchase_robot`.
- It adds `SET search_path = 'public'` to each function, which is a security best practice recommended by Supabase.
- This change has no impact on existing data and does not alter the function's logic. It is a safe and reversible operation.

## Metadata:
- Schema-Category: ["Safe", "Structural"]
- Impact-Level: ["Low"]
- Requires-Backup: false
- Reversible: true

## Structure Details:
- Modifies function: `public.handle_new_user`
- Modifies function: `public.handle_first_deposit`
- Modifies function: `public.purchase_robot`

## Security Implications:
- RLS Status: Unchanged
- Policy Changes: No
- Auth Requirements: Admin privileges to alter functions.
- Fixes "Function Search Path Mutable" warnings.

## Performance Impact:
- Indexes: None
- Triggers: Unchanged
- Estimated Impact: Negligible.
*/

-- Secure the handle_new_user function
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  -- Create a profile for the new user
  INSERT INTO public.profiles (user_id, email, full_name, cpf, phone, referral_code, referred_by)
  VALUES (
    new.id,
    new.email,
    new.raw_user_meta_data->>'full_name',
    new.raw_user_meta_data->>'cpf',
    new.raw_user_meta_data->>'phone',
    substring(md5(random()::text) for 10),
    (SELECT user_id FROM public.profiles WHERE referral_code = new.raw_user_meta_data->>'referral_code' LIMIT 1)
  );

  -- Check if the user was referred
  IF new.raw_user_meta_data->>'referral_code' IS NOT NULL THEN
    -- Give R$10 bonus to the new user for being referred
    INSERT INTO public.referral_bonuses (user_id, amount, reason)
    VALUES (new.id, 10, 'Bônus de cadastro por indicação');
  END IF;

  RETURN new;
END;
$$;

-- Secure the handle_first_deposit function
CREATE OR REPLACE FUNCTION public.handle_first_deposit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  v_referred_by_id UUID;
BEGIN
  -- Check if it's the user's first deposit
  IF (SELECT count(*) FROM public.deposits WHERE user_id = new.user_id) = 1 THEN
    -- Find who referred this user
    SELECT referred_by INTO v_referred_by_id
    FROM public.profiles
    WHERE user_id = new.user_id;

    -- If the user was referred, give a bonus to the referrer
    IF v_referred_by_id IS NOT NULL THEN
      INSERT INTO public.referral_bonuses (user_id, amount, reason, source_user_id)
      VALUES (v_referred_by_id, 10, 'Bônus de indicação', new.user_id);
    END IF;
  END IF;

  RETURN new;
END;
$$;


-- Secure the purchase_robot function
CREATE OR REPLACE FUNCTION public.purchase_robot(
  p_robot_id text,
  p_amount numeric
)
RETURNS TABLE (success boolean, message text)
LANGUAGE plpgsql
SET search_path = 'public'
AS $$
DECLARE
  v_user_id uuid := auth.uid();
  v_total_deposits numeric;
  v_total_withdrawals numeric;
  v_total_investments numeric;
  v_total_bonuses numeric;
  v_current_balance numeric;
  v_robot_period int;
BEGIN
  -- Calculate current balance
  SELECT COALESCE(SUM(amount), 0) INTO v_total_deposits FROM public.deposits WHERE user_id = v_user_id;
  SELECT COALESCE(SUM(amount), 0) INTO v_total_withdrawals FROM public.withdrawals WHERE user_id = v_user_id AND status = 'completed';
  SELECT COALESCE(SUM(amount), 0) INTO v_total_investments FROM public.investments WHERE user_id = v_user_id;
  SELECT COALESCE(SUM(amount), 0) INTO v_total_bonuses FROM public.referral_bonuses WHERE user_id = v_user_id;

  v_current_balance := (v_total_deposits + v_total_bonuses) - v_total_withdrawals - v_total_investments;

  -- Check if balance is sufficient
  IF v_current_balance < p_amount THEN
    RETURN QUERY SELECT false, 'Saldo insuficiente para realizar este investimento.';
    RETURN;
  END IF;

  -- Get robot details (this is a simplification, ideally this data comes from a table)
  CASE p_robot_id
    WHEN '1' THEN v_robot_period := 30;
    WHEN '2' THEN v_robot_period := 45;
    WHEN '3' THEN v_robot_period := 45;
    WHEN '4' THEN v_robot_period := 45;
    WHEN '5' THEN v_robot_period := 45;
    ELSE
      RETURN QUERY SELECT false, 'Robô inválido selecionado.';
      RETURN;
  END CASE;

  -- Insert the new investment
  INSERT INTO public.investments (user_id, robot_id, amount, end_date)
  VALUES (v_user_id, p_robot_id, p_amount, now() + (v_robot_period || ' days')::interval);

  RETURN QUERY SELECT true, 'Investimento realizado com sucesso!';
END;
$$;
