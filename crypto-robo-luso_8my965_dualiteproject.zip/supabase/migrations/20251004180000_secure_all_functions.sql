-- Remove gatilhos dependentes primeiro
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP TRIGGER IF EXISTS on_first_deposit ON public.deposits;
DROP TRIGGER IF EXISTS update_balance_on_deposit ON public.deposits;
DROP TRIGGER IF EXISTS update_balance_on_investment ON public.investments;
DROP TRIGGER IF EXISTS update_balance_on_withdrawal ON public.withdrawals;
DROP TRIGGER IF EXISTS update_balance_on_bonus ON public.referral_bonuses;

-- Remove as funções antigas
DROP FUNCTION IF EXISTS public.handle_new_user();
DROP FUNCTION IF EXISTS public.handle_first_deposit();
DROP FUNCTION IF EXISTS public.update_balance_on_deposit();
DROP FUNCTION IF EXISTS public.update_balance_on_investment();
DROP FUNCTION IF EXISTS public.update_balance_on_withdrawal();
DROP FUNCTION IF EXISTS public.update_balance_on_bonus();
DROP FUNCTION IF EXISTS public.purchase_robot(uuid,text,numeric,integer);
DROP FUNCTION IF EXISTS public.generate_referral_code();

-- Recria a função para gerar código de referência de forma segura
CREATE OR REPLACE FUNCTION public.generate_referral_code()
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  new_code TEXT;
  is_duplicate BOOLEAN;
BEGIN
  LOOP
    new_code := upper(substr(md5(random()::text), 0, 7));
    SELECT EXISTS (SELECT 1 FROM profiles WHERE referral_code = new_code) INTO is_duplicate;
    IF NOT is_duplicate THEN
      RETURN new_code;
    END IF;
  END LOOP;
END;
$$;

-- Recria a função para criar novo usuário de forma segura
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  referrer_id UUID;
BEGIN
  -- Insere o perfil básico
  INSERT INTO public.profiles (user_id, email, full_name, cpf, phone, referral_code)
  VALUES (
    NEW.id,
    NEW.email,
    NEW.raw_user_meta_data->>'full_name',
    NEW.raw_user_meta_data->>'cpf',
    NEW.raw_user_meta_data->>'phone',
    public.generate_referral_code()
  );

  -- Aplica bônus se houver código de referência
  IF NEW.raw_user_meta_data->>'referral_code' IS NOT NULL THEN
    SELECT user_id INTO referrer_id FROM public.profiles WHERE referral_code = NEW.raw_user_meta_data->>'referral_code';
    IF referrer_id IS NOT NULL THEN
      UPDATE public.profiles SET referred_by = referrer_id WHERE user_id = NEW.id;
      INSERT INTO public.referral_bonuses (user_id, amount, reason, source_user_id)
      VALUES (NEW.id, 10, 'Bônus de cadastro por indicação', referrer_id);
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Recria a função para o primeiro depósito de forma segura
CREATE OR REPLACE FUNCTION public.handle_first_deposit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  referrer_id UUID;
  deposit_count INT;
BEGIN
  -- Verifica se é o primeiro depósito
  SELECT count(*) INTO deposit_count FROM public.deposits WHERE user_id = NEW.user_id;

  IF deposit_count = 1 THEN
    SELECT referred_by INTO referrer_id FROM public.profiles WHERE user_id = NEW.user_id;
    IF referrer_id IS NOT NULL THEN
      INSERT INTO public.referral_bonuses (user_id, amount, reason, source_user_id)
      VALUES (referrer_id, 10, 'Bônus de indicação', NEW.user_id);
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Recria as funções de atualização de saldo de forma segura
CREATE OR REPLACE FUNCTION public.update_balance_on_deposit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  UPDATE public.profiles
  SET balance = balance + NEW.amount
  WHERE user_id = NEW.user_id;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_balance_on_investment()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  UPDATE public.profiles
  SET balance = balance - NEW.amount
  WHERE user_id = NEW.user_id;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_balance_on_withdrawal()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  IF NEW.status = 'pending' THEN
    UPDATE public.profiles
    SET balance = balance - NEW.amount
    WHERE user_id = NEW.user_id;
  END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_balance_on_bonus()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  UPDATE public.profiles
  SET balance = balance + NEW.amount
  WHERE user_id = NEW.user_id;
  RETURN NEW;
END;
$$;

-- Recria a função de compra de robô de forma segura
CREATE OR REPLACE FUNCTION public.purchase_robot(p_user_id uuid, p_robot_id text, p_amount numeric, p_period_days integer)
RETURNS TABLE(success boolean, message text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  v_current_balance numeric;
BEGIN
  -- Obtém o saldo diretamente do perfil
  SELECT balance INTO v_current_balance FROM public.profiles WHERE user_id = p_user_id;

  -- Verifica se o saldo é suficiente
  IF v_current_balance < p_amount THEN
    RETURN QUERY SELECT false, 'Saldo insuficiente para realizar este investimento.';
    RETURN;
  END IF;

  -- Insere o novo investimento
  INSERT INTO public.investments (user_id, robot_id, amount, end_date)
  VALUES (p_user_id, p_robot_id, p_amount, now() + (p_period_days || ' days')::interval);

  RETURN QUERY SELECT true, 'Investimento realizado com sucesso!';
END;
$$;

-- Recria todos os gatilhos
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE TRIGGER on_first_deposit
  AFTER INSERT ON public.deposits
  FOR EACH ROW EXECUTE FUNCTION public.handle_first_deposit();
  
CREATE TRIGGER update_balance_on_deposit
  AFTER INSERT ON public.deposits
  FOR EACH ROW EXECUTE FUNCTION public.update_balance_on_deposit();

CREATE TRIGGER update_balance_on_investment
  AFTER INSERT ON public.investments
  FOR EACH ROW EXECUTE FUNCTION public.update_balance_on_investment();

CREATE TRIGGER update_balance_on_withdrawal
  AFTER INSERT ON public.withdrawals
  FOR EACH ROW EXECUTE FUNCTION public.update_balance_on_withdrawal();

CREATE TRIGGER update_balance_on_bonus
  AFTER INSERT ON public.referral_bonuses
  FOR EACH ROW EXECUTE FUNCTION public.update_balance_on_bonus();
