-- Drop dependent triggers first to avoid dependency errors
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP TRIGGER IF EXISTS on_first_deposit ON public.deposits;
DROP TRIGGER IF EXISTS update_balance_on_deposit ON public.deposits;
DROP TRIGGER IF EXISTS update_balance_on_investment ON public.investments;
DROP TRIGGER IF EXISTS update_balance_on_withdrawal ON public.withdrawals;
DROP TRIGGER IF EXISTS update_balance_on_bonus ON public.referral_bonuses;

-- Drop functions now that triggers are removed
DROP FUNCTION IF EXISTS public.handle_new_user();
DROP FUNCTION IF EXISTS public.handle_first_deposit();
DROP FUNCTION IF EXISTS public.update_balance_on_deposit();
DROP FUNCTION IF EXISTS public.update_balance_on_investment();
DROP FUNCTION IF EXISTS public.update_balance_on_withdrawal();
DROP FUNCTION IF EXISTS public.update_balance_on_bonus();
DROP FUNCTION IF EXISTS public.purchase_robot(uuid, text, numeric, integer, text);
DROP FUNCTION IF EXISTS public.generate_referral_code();

-- Recreate functions with security settings

-- Function to generate a unique referral code
CREATE OR REPLACE FUNCTION public.generate_referral_code()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  new_code TEXT;
  code_exists BOOLEAN;
BEGIN
  LOOP
    new_code := substr(upper(md5(random()::text)), 1, 8);
    SELECT EXISTS (SELECT 1 FROM profiles WHERE referral_code = new_code) INTO code_exists;
    EXIT WHEN NOT code_exists;
  END LOOP;
  RETURN new_code;
END;
$$;

-- Function to create a user profile
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  referrer_id UUID;
BEGIN
  -- Find referrer if a valid code was provided
  IF NEW.raw_user_meta_data->>'referral_code' IS NOT NULL THEN
    SELECT user_id INTO referrer_id FROM profiles WHERE referral_code = NEW.raw_user_meta_data->>'referral_code';
  END IF;

  -- Insert new profile
  INSERT INTO public.profiles (user_id, email, full_name, cpf, phone, referred_by)
  VALUES (
    NEW.id,
    NEW.email,
    NEW.raw_user_meta_data->>'full_name',
    NEW.raw_user_meta_data->>'cpf',
    NEW.raw_user_meta_data->>'phone',
    referrer_id
  );

  -- Grant R$10 bonus to the new user for signing up
  INSERT INTO public.referral_bonuses (user_id, amount, reason)
  VALUES (NEW.id, 10, 'Bônus de cadastro');

  RETURN NEW;
END;
$$;

-- Function to handle the first deposit bonus
CREATE OR REPLACE FUNCTION public.handle_first_deposit()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  referrer_profile RECORD;
  deposit_count INT;
BEGIN
  -- Check if this is the user's first deposit
  SELECT count(*) INTO deposit_count FROM public.deposits WHERE user_id = NEW.user_id;

  IF deposit_count = 1 THEN
    -- Find who referred the new user
    SELECT p.user_id, p.referred_by INTO referrer_profile
    FROM public.profiles p WHERE p.user_id = NEW.user_id;

    -- If the user was referred, give a bonus to the referrer
    IF referrer_profile.referred_by IS NOT NULL THEN
      INSERT INTO public.referral_bonuses (user_id, amount, reason, source_user_id)
      VALUES (referrer_profile.referred_by, 10, 'Bônus de indicação', NEW.user_id);
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

-- Balance update functions
CREATE OR REPLACE FUNCTION public.update_balance_on_deposit()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  UPDATE public.profiles
  SET balance = balance + NEW.amount
  WHERE user_id = NEW.user_id;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_balance_on_investment()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  UPDATE public.profiles
  SET balance = balance - NEW.amount
  WHERE user_id = NEW.user_id;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_balance_on_withdrawal()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.profiles
    SET balance = balance - NEW.amount
    WHERE user_id = NEW.user_id;
  END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_balance_on_bonus()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  UPDATE public.profiles
  SET balance = balance + NEW.amount
  WHERE user_id = NEW.user_id;
  RETURN NEW;
END;
$$;

-- Function to purchase a robot
CREATE OR REPLACE FUNCTION public.purchase_robot(p_user_id uuid, p_robot_id text, p_amount numeric, p_period_days integer, p_coin_id text)
RETURNS TABLE(success boolean, message text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  v_current_balance numeric;
BEGIN
  -- Get current balance directly from the profile
  SELECT balance INTO v_current_balance FROM public.profiles WHERE user_id = p_user_id;

  -- Check if balance is sufficient
  IF v_current_balance < p_amount THEN
    RETURN QUERY SELECT false, 'Saldo insuficiente para realizar este investimento.';
    RETURN;
  END IF;

  -- Insert the new investment
  INSERT INTO public.investments (user_id, robot_id, amount, end_date, coin_id)
  VALUES (p_user_id, p_robot_id, p_amount, now() + (p_period_days || ' days')::interval, p_coin_id);

  RETURN QUERY SELECT true, 'Investimento realizado com sucesso!';
END;
$$;


-- Recreate triggers
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE TRIGGER on_first_deposit
  AFTER INSERT ON public.deposits
  FOR EACH ROW EXECUTE FUNCTION public.handle_first_deposit();

CREATE TRIGGER update_balance_on_deposit
  AFTER INSERT ON public.deposits
  FOR EACH ROW EXECUTE FUNCTION public.update_balance_on_deposit();

CREATE TRIGGER update_balance_on_investment
  AFTER INSERT ON public.investments
  FOR EACH ROW EXECUTE FUNCTION public.update_balance_on_investment();

CREATE TRIGGER update_balance_on_withdrawal
  AFTER INSERT ON public.withdrawals
  FOR EACH ROW EXECUTE FUNCTION public.update_balance_on_withdrawal();

CREATE TRIGGER update_balance_on_bonus
  AFTER INSERT ON public.referral_bonuses
  FOR EACH ROW EXECUTE FUNCTION public.update_balance_on_bonus();
