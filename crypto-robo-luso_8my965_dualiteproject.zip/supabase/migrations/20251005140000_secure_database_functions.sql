-- Remove o gatilho e a função antigos para evitar conflitos
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user();

DROP TRIGGER IF EXISTS on_first_deposit ON public.deposits;
DROP FUNCTION IF EXISTS public.handle_first_deposit();

DROP TRIGGER IF EXISTS update_balance_on_deposit ON public.deposits;
DROP FUNCTION IF EXISTS public.update_balance_on_deposit();

DROP TRIGGER IF EXISTS update_balance_on_withdrawal ON public.withdrawals;
DROP FUNCTION IF EXISTS public.update_balance_on_withdrawal();

DROP TRIGGER IF EXISTS update_balance_on_investment ON public.investments;
DROP FUNCTION IF EXISTS public.update_balance_on_investment();

DROP TRIGGER IF EXISTS update_balance_on_bonus ON public.referral_bonuses;
DROP FUNCTION IF EXISTS public.update_balance_on_bonus();

DROP FUNCTION IF EXISTS public.purchase_robot(uuid, text, numeric, integer);
DROP FUNCTION IF EXISTS public.generate_referral_code();


-- Recria a função para gerar código de referência com segurança
CREATE OR REPLACE FUNCTION public.generate_referral_code()
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    new_code TEXT;
    is_duplicate BOOLEAN;
BEGIN
    LOOP
        new_code := upper(substr(md5(random()::text), 0, 9));
        SELECT EXISTS (SELECT 1 FROM profiles WHERE referral_code = new_code) INTO is_duplicate;
        IF NOT is_duplicate THEN
            RETURN new_code;
        END IF;
    END LOOP;
END;
$$;


-- Recria a função para lidar com novos usuários com segurança
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    referrer_id UUID;
BEGIN
    -- Insere o novo perfil
    INSERT INTO public.profiles (user_id, email, full_name, cpf, phone, referral_code, referred_by)
    VALUES (
        new.id,
        new.email,
        new.raw_user_meta_data->>'full_name',
        new.raw_user_meta_data->>'cpf',
        new.raw_user_meta_data->>'phone',
        public.generate_referral_code(),
        (SELECT p.user_id FROM public.profiles p WHERE p.referral_code = (new.raw_user_meta_data->>'referral_code'))
    );

    -- Concede bônus de cadastro
    INSERT INTO public.referral_bonuses (user_id, amount, reason)
    VALUES (new.id, 10, 'Bônus de cadastro');

    RETURN new;
END;
$$;

-- Recria o gatilho para novos usuários
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();


-- Recria a função para lidar com o primeiro depósito com segurança
CREATE OR REPLACE FUNCTION public.handle_first_deposit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    referrer_profile RECORD;
BEGIN
    -- Verifica se é o primeiro depósito do usuário
    IF (SELECT count(*) FROM public.deposits WHERE user_id = NEW.user_id) = 1 THEN
        -- Encontra quem indicou o usuário
        SELECT * INTO referrer_profile FROM public.profiles WHERE user_id = (
            SELECT referred_by FROM public.profiles WHERE user_id = NEW.user_id
        );

        -- Se houver um indicador, concede o bônus
        IF FOUND THEN
            INSERT INTO public.referral_bonuses (user_id, amount, reason, source_user_id)
            VALUES (referrer_profile.user_id, 10, 'Bônus de indicação', NEW.user_id);
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

-- Recria o gatilho para o primeiro depósito
CREATE TRIGGER on_first_deposit
  AFTER INSERT ON public.deposits
  FOR EACH ROW EXECUTE FUNCTION public.handle_first_deposit();


-- Funções de atualização de saldo
CREATE OR REPLACE FUNCTION public.update_balance_on_deposit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.profiles
  SET balance = balance + NEW.amount
  WHERE user_id = NEW.user_id;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_balance_on_withdrawal()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.profiles
  SET balance = balance - NEW.amount
  WHERE user_id = NEW.user_id;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_balance_on_investment()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.profiles
  SET balance = balance - NEW.amount
  WHERE user_id = NEW.user_id;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_balance_on_bonus()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.profiles
  SET balance = balance + NEW.amount
  WHERE user_id = NEW.user_id;
  RETURN NEW;
END;
$$;

-- Recria os gatilhos de atualização de saldo
CREATE TRIGGER update_balance_on_deposit
  AFTER INSERT ON public.deposits
  FOR EACH ROW EXECUTE FUNCTION public.update_balance_on_deposit();

CREATE TRIGGER update_balance_on_withdrawal
  AFTER INSERT ON public.withdrawals
  FOR EACH ROW EXECUTE FUNCTION public.update_balance_on_withdrawal();

CREATE TRIGGER update_balance_on_investment
  AFTER INSERT ON public.investments
  FOR EACH ROW EXECUTE FUNCTION public.update_balance_on_investment();

CREATE TRIGGER update_balance_on_bonus
  AFTER INSERT ON public.referral_bonuses
  FOR EACH ROW EXECUTE FUNCTION public.update_balance_on_bonus();


-- Recria a função de compra de robô com segurança
CREATE OR REPLACE FUNCTION public.purchase_robot(
  p_user_id uuid,
  p_robot_id text,
  p_amount numeric,
  p_period_days integer
)
RETURNS TABLE (success boolean, message text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_current_balance numeric;
BEGIN
  -- Obtém o saldo diretamente do perfil do usuário
  SELECT balance INTO v_current_balance FROM public.profiles WHERE user_id = p_user_id;

  -- Verifica se o saldo é suficiente
  IF v_current_balance < p_amount THEN
    RETURN QUERY SELECT false, 'Saldo insuficiente para realizar este investimento.';
    RETURN;
  END IF;

  -- Insere o novo investimento
  INSERT INTO public.investments (user_id, robot_id, amount, end_date)
  VALUES (p_user_id, p_robot_id, p_amount, now() + (p_period_days || ' days')::interval);
  
  RETURN QUERY SELECT true, 'Investimento realizado com sucesso!';
END;
$$;
