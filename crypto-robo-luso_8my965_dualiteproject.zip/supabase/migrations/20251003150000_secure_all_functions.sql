-- Recria a função handle_new_user com segurança
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    referral_user_id UUID;
    new_referral_code TEXT;
BEGIN
    -- Gera um código de referência único
    new_referral_code := substr(md5(random()::text), 0, 9);

    -- Verifica se o novo usuário foi referido
    IF new.raw_user_meta_data ? 'referral_code' THEN
        SELECT user_id INTO referral_user_id
        FROM public.profiles
        WHERE referral_code = (new.raw_user_meta_data->>'referral_code');
    END IF;

    -- Insere o novo perfil
    INSERT INTO public.profiles (user_id, email, full_name, cpf, phone, referral_code, referred_by)
    VALUES (
        new.id,
        new.email,
        new.raw_user_meta_data->>'full_name',
        new.raw_user_meta_data->>'cpf',
        new.raw_user_meta_data->>'phone',
        new_referral_code,
        referral_user_id
    );

    -- Aplica bônus de cadastro
    INSERT INTO public.referral_bonuses (user_id, amount, reason, source_user_id)
    VALUES (new.id, 10, 'Bônus de cadastro', NULL);

    RETURN new;
END;
$$;

-- Recria a função handle_first_deposit com segurança
CREATE OR REPLACE FUNCTION public.handle_first_deposit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    referrer_id UUID;
BEGIN
    -- Verifica se é o primeiro depósito do usuário
    IF (SELECT count(*) FROM public.deposits WHERE user_id = NEW.user_id) = 1 THEN
        -- Encontra quem indicou o usuário
        SELECT referred_by INTO referrer_id
        FROM public.profiles
        WHERE user_id = NEW.user_id;

        -- Se houver um indicador, aplica o bônus
        IF referrer_id IS NOT NULL THEN
            INSERT INTO public.referral_bonuses (user_id, amount, reason, source_user_id)
            VALUES (referrer_id, 10, 'Bônus de indicação', NEW.user_id);
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

-- Recria a função purchase_robot com segurança
CREATE OR REPLACE FUNCTION public.purchase_robot(p_user_id uuid, p_robot_id text, p_amount numeric, p_period_days integer)
RETURNS TABLE(success boolean, message text)
LANGUAGE plpgsql
SET search_path = public
AS $$
DECLARE
  v_total_deposits numeric;
  v_total_withdrawals numeric;
  v_total_investments numeric;
  v_total_bonuses numeric;
  v_current_balance numeric;
BEGIN
  -- Calcula o saldo atual
  SELECT COALESCE(SUM(amount), 0) INTO v_total_deposits FROM public.deposits WHERE user_id = p_user_id;
  SELECT COALESCE(SUM(amount), 0) INTO v_total_withdrawals FROM public.withdrawals WHERE user_id = p_user_id AND status = 'completed';
  SELECT COALESCE(SUM(amount), 0) INTO v_total_investments FROM public.investments WHERE user_id = p_user_id;
  SELECT COALESCE(SUM(amount), 0) INTO v_total_bonuses FROM public.referral_bonuses WHERE user_id = p_user_id;

  v_current_balance := (v_total_deposits + v_total_bonuses) - v_total_withdrawals - v_total_investments;

  -- Verifica se o saldo é suficiente
  IF v_current_balance < p_amount THEN
    RETURN QUERY SELECT false, 'Saldo insuficiente para realizar este investimento.';
    RETURN;
  END IF;

  -- Insere o novo investimento
  INSERT INTO public.investments (user_id, robot_id, amount, end_date)
  VALUES (p_user_id, p_robot_id, p_amount, now() + (p_period_days || ' days')::interval);
  
  RETURN QUERY SELECT true, 'Investimento realizado com sucesso!';
END;
$$;
