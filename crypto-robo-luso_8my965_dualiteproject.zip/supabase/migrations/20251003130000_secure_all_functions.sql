-- Drop existing triggers and functions to redefine them securely
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP TRIGGER IF EXISTS on_first_deposit ON public.deposits;

DROP FUNCTION IF EXISTS public.handle_new_user();
DROP FUNCTION IF EXISTS public.handle_first_deposit();
DROP FUNCTION IF EXISTS public.purchase_robot(uuid, text, numeric, integer);


-- Function to create a profile for a new user and grant signup bonus
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = '';
AS $$
DECLARE
  referral_bonus_amount NUMERIC := 10;
  signup_bonus_amount NUMERIC := 10;
  referrer_id_val UUID;
BEGIN
  -- Create a profile for the new user
  INSERT INTO public.profiles (user_id, email, full_name, cpf, phone, referral_code, referred_by)
  VALUES (
    new.id,
    new.email,
    new.raw_user_meta_data->>'full_name',
    new.raw_user_meta_data->>'cpf',
    new.raw_user_meta_data->>'phone',
    substring(replace(gen_random_uuid()::text, '-', ''), 1, 8),
    (SELECT user_id FROM public.profiles WHERE referral_code = new.raw_user_meta_data->>'referral_code' LIMIT 1)
  );

  -- Grant signup bonus to the new user
  INSERT INTO public.referral_bonuses (user_id, amount, reason)
  VALUES (new.id, signup_bonus_amount, 'Bônus de cadastro');

  RETURN new;
END;
$$;

-- Trigger to execute the function when a new user signs up
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();


-- Function to grant bonus to the referrer on the first deposit of the referred user
CREATE OR REPLACE FUNCTION public.handle_first_deposit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = '';
AS $$
DECLARE
  referrer_id_val UUID;
  deposit_count INTEGER;
  referral_bonus_amount NUMERIC := 10;
BEGIN
  -- Check if this is the user's first deposit
  SELECT count(*) INTO deposit_count FROM public.deposits WHERE user_id = new.user_id;

  IF deposit_count = 1 THEN
    -- Find who referred this user
    SELECT referred_by INTO referrer_id_val FROM public.profiles WHERE user_id = new.user_id;

    -- If the user was referred, grant a bonus to the referrer
    IF referrer_id_val IS NOT NULL THEN
      INSERT INTO public.referral_bonuses (user_id, amount, reason, source_user_id)
      VALUES (referrer_id_val, referral_bonus_amount, 'Bônus de indicação', new.user_id);
    END IF;
  END IF;

  RETURN new;
END;
$$;

-- Trigger to execute the function on a new deposit
CREATE TRIGGER on_first_deposit
  AFTER INSERT ON public.deposits
  FOR EACH ROW EXECUTE PROCEDURE public.handle_first_deposit();


-- Function to purchase a robot, ensuring user has enough balance
CREATE OR REPLACE FUNCTION public.purchase_robot(p_user_id uuid, p_robot_id text, p_amount numeric, p_period_days integer)
RETURNS TABLE(success boolean, message text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = '';
AS $$
DECLARE
  v_total_deposits NUMERIC;
  v_total_bonuses NUMERIC;
  v_total_withdrawals NUMERIC;
  v_total_investments NUMERIC;
  v_current_balance NUMERIC;
BEGIN
  -- Calculate current balance
  SELECT COALESCE(SUM(amount), 0) INTO v_total_deposits FROM public.deposits WHERE user_id = p_user_id;
  SELECT COALESCE(SUM(amount), 0) INTO v_total_bonuses FROM public.referral_bonuses WHERE user_id = p_user_id;
  SELECT COALESCE(SUM(amount), 0) INTO v_total_withdrawals FROM public.withdrawals WHERE user_id = p_user_id AND status = 'completed';
  SELECT COALESCE(SUM(amount), 0) INTO v_total_investments FROM public.investments WHERE user_id = p_user_id;

  v_current_balance := v_total_deposits + v_total_bonuses - v_total_withdrawals - v_total_investments;

  -- Check if balance is sufficient
  IF v_current_balance < p_amount THEN
    RETURN QUERY SELECT FALSE, 'Saldo insuficiente para realizar este investimento.';
    RETURN;
  END IF;

  -- Insert the new investment
  INSERT INTO public.investments (user_id, robot_id, amount, end_date)
  VALUES (p_user_id, p_robot_id, p_amount, NOW() + (p_period_days || ' days')::INTERVAL);

  RETURN QUERY SELECT TRUE, 'Investimento realizado com sucesso!';
END;
$$;
