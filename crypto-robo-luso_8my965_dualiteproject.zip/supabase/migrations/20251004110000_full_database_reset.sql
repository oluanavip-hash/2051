-- =============================================
--      FASE 1: LIMPEZA COMPLETA
-- Remove objetos na ordem correta para evitar erros de dependência.
-- =============================================

-- 1. Remove os gatilhos que dependem das funções
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP TRIGGER IF EXISTS on_first_deposit ON public.deposits;

-- 2. Remove as funções
DROP FUNCTION IF EXISTS public.handle_new_user();
DROP FUNCTION IF EXISTS public.handle_first_deposit();
DROP FUNCTION IF EXISTS public.purchase_robot(uuid, text, numeric, integer);
DROP FUNCTION IF EXISTS public.generate_referral_code();

-- 3. Remove as tabelas (usando CASCADE para garantir a remoção de dependências)
DROP TABLE IF EXISTS public.referral_bonuses;
DROP TABLE IF EXISTS public.investments;
DROP TABLE IF EXISTS public.withdrawals;
DROP TABLE IF EXISTS public.deposits;
DROP TABLE IF EXISTS public.profiles;


-- =============================================
--      FASE 2: RECRIAÇÃO DA ESTRUTURA
-- Cria tabelas, funções e gatilhos na ordem correta.
-- =============================================

-- 1. Tabela de Perfis (profiles)
CREATE TABLE public.profiles (
    user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email text,
    full_name text,
    cpf text,
    phone text,
    referral_code text UNIQUE,
    referred_by uuid REFERENCES public.profiles(user_id),
    created_at timestamptz DEFAULT now() NOT NULL,
    updated_at timestamptz DEFAULT now() NOT NULL
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Usuários podem ver seus próprios perfis" ON public.profiles FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Usuários podem atualizar seus próprios perfis" ON public.profiles FOR UPDATE USING (auth.uid() = user_id);

-- 2. Tabela de Depósitos (deposits)
CREATE TABLE public.deposits (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL REFERENCES auth.users(id),
    amount numeric NOT NULL,
    status text DEFAULT 'completed'::text NOT NULL,
    created_at timestamptz DEFAULT now() NOT NULL,
    updated_at timestamptz DEFAULT now() NOT NULL
);
ALTER TABLE public.deposits ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Usuários podem ver seus próprios depósitos" ON public.deposits FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Usuários podem criar depósitos" ON public.deposits FOR INSERT WITH CHECK (auth.uid() = user_id);

-- 3. Tabela de Saques (withdrawals)
CREATE TABLE public.withdrawals (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL REFERENCES auth.users(id),
    amount numeric NOT NULL,
    wallet_address text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    created_at timestamptz DEFAULT now() NOT NULL,
    updated_at timestamptz DEFAULT now() NOT NULL
);
ALTER TABLE public.withdrawals ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Usuários podem ver seus próprios saques" ON public.withdrawals FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Usuários podem criar saques" ON public.withdrawals FOR INSERT WITH CHECK (auth.uid() = user_id);

-- 4. Tabela de Investimentos (investments)
CREATE TABLE public.investments (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL REFERENCES auth.users(id),
    robot_id text NOT NULL,
    amount numeric NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    start_date timestamptz DEFAULT now() NOT NULL,
    end_date timestamptz NOT NULL,
    created_at timestamptz DEFAULT now() NOT NULL,
    updated_at timestamptz DEFAULT now() NOT NULL
);
ALTER TABLE public.investments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Usuários podem ver seus próprios investimentos" ON public.investments FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Usuários podem criar investimentos" ON public.investments FOR INSERT WITH CHECK (auth.uid() = user_id);

-- 5. Tabela de Bônus de Referência (referral_bonuses)
CREATE TABLE public.referral_bonuses (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL REFERENCES auth.users(id),
    amount numeric NOT NULL,
    reason text NOT NULL,
    source_user_id uuid REFERENCES auth.users(id),
    created_at timestamptz DEFAULT now() NOT NULL
);
ALTER TABLE public.referral_bonuses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Usuários podem ver seus próprios bônus" ON public.referral_bonuses FOR SELECT USING (auth.uid() = user_id);

-- =============================================
--      FASE 3: FUNÇÕES E GATILHOS (AUTOMATIZAÇÃO)
-- =============================================

-- 1. Função para gerar código de referência único
CREATE OR REPLACE FUNCTION public.generate_referral_code()
RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
  new_code text;
  is_duplicate boolean;
BEGIN
  LOOP
    new_code := upper(substr(md5(random()::text), 1, 8));
    SELECT EXISTS (SELECT 1 FROM public.profiles WHERE referral_code = new_code) INTO is_duplicate;
    EXIT WHEN NOT is_duplicate;
  END LOOP;
  RETURN new_code;
END;
$$;

-- 2. Função para criar perfil de novo usuário e aplicar bônus de cadastro
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  referrer_id uuid;
  referral_code_from_form text;
BEGIN
  -- Extrai o código de referência dos metadados do usuário
  referral_code_from_form := new.raw_user_meta_data->>'referral_code';

  -- Encontra o ID do usuário que indicou, se um código válido foi fornecido
  IF referral_code_from_form IS NOT NULL AND referral_code_from_form != '' THEN
    SELECT user_id INTO referrer_id FROM public.profiles WHERE referral_code = referral_code_from_form;
  END IF;

  -- Insere o novo perfil
  INSERT INTO public.profiles (user_id, email, full_name, cpf, phone, referred_by, referral_code)
  VALUES (
    new.id,
    new.email,
    new.raw_user_meta_data->>'full_name',
    new.raw_user_meta_data->>'cpf',
    new.raw_user_meta_data->>'phone',
    referrer_id,
    public.generate_referral_code()
  );

  -- Se foi indicado, dá o bônus de R$10 para o novo usuário
  IF referrer_id IS NOT NULL THEN
    INSERT INTO public.referral_bonuses (user_id, amount, reason, source_user_id)
    VALUES (new.id, 10, 'Bônus de cadastro por indicação', referrer_id);
  END IF;

  RETURN new;
END;
$$;

-- 3. Gatilho para chamar a função handle_new_user
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW
EXECUTE FUNCTION public.handle_new_user();

-- 4. Função para dar bônus no primeiro depósito
CREATE OR REPLACE FUNCTION public.handle_first_deposit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  referrer_id uuid;
  deposit_count integer;
BEGIN
  -- Verifica se é o primeiro depósito do usuário
  SELECT count(*) INTO deposit_count FROM public.deposits WHERE user_id = new.user_id;

  IF deposit_count = 1 THEN
    -- Encontra quem indicou o usuário
    SELECT referred_by INTO referrer_id FROM public.profiles WHERE user_id = new.user_id;

    -- Se houver um indicador, dá o bônus de R$10 para ele
    IF referrer_id IS NOT NULL THEN
      INSERT INTO public.referral_bonuses (user_id, amount, reason, source_user_id)
      VALUES (referrer_id, 10, 'Bônus de indicação', new.user_id);
    END IF;
  END IF;

  RETURN new;
END;
$$;

-- 5. Gatilho para chamar a função handle_first_deposit
CREATE TRIGGER on_first_deposit
AFTER INSERT ON public.deposits
FOR EACH ROW
EXECUTE FUNCTION public.handle_first_deposit();

-- 6. Função para comprar robô (transação segura)
CREATE OR REPLACE FUNCTION public.purchase_robot(p_user_id uuid, p_robot_id text, p_amount numeric, p_period_days integer)
RETURNS TABLE(success boolean, message text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_total_deposits numeric;
  v_total_withdrawals numeric;
  v_total_investments numeric;
  v_total_bonuses numeric;
  v_current_balance numeric;
BEGIN
  -- Calcula o saldo atual do usuário
  SELECT COALESCE(SUM(amount), 0) INTO v_total_deposits FROM public.deposits WHERE user_id = p_user_id;
  SELECT COALESCE(SUM(amount), 0) INTO v_total_withdrawals FROM public.withdrawals WHERE user_id = p_user_id AND status = 'completed';
  SELECT COALESCE(SUM(amount), 0) INTO v_total_investments FROM public.investments WHERE user_id = p_user_id;
  SELECT COALESCE(SUM(amount), 0) INTO v_total_bonuses FROM public.referral_bonuses WHERE user_id = p_user_id;
  
  v_current_balance := (v_total_deposits + v_total_bonuses) - v_total_withdrawals - v_total_investments;

  -- Verifica se o saldo é suficiente
  IF v_current_balance < p_amount THEN
    RETURN QUERY SELECT false, 'Saldo insuficiente para realizar este investimento.';
    RETURN;
  END IF;

  -- Insere o novo investimento
  INSERT INTO public.investments (user_id, robot_id, amount, end_date)
  VALUES (p_user_id, p_robot_id, p_amount, now() + (p_period_days || ' days')::interval);
  
  RETURN QUERY SELECT true, 'Investimento realizado com sucesso!';
END;
$$;

-- Grant permissions for authenticated users to call functions
GRANT EXECUTE ON FUNCTION public.purchase_robot(uuid, text, numeric, integer) TO authenticated;
GRANT EXECUTE ON FUNCTION public.generate_referral_code() TO authenticated;
</sql>
