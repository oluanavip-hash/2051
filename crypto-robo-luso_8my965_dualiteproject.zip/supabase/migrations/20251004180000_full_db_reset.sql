-- =================================================================
--  SCRIPT DE RESET COMPLETO DO BANCO DE DADOS
--  Este script irá apagar e recriar toda a estrutura da aplicação.
--  Execute-o uma única vez para resolver todos os erros de migração.
-- =================================================================

-- 1. DROP ALL DEPENDENT OBJECTS (TRIGGERS, FUNCTIONS, TABLES)
-- Drop triggers safely
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users CASCADE;
DROP TRIGGER IF EXISTS on_first_deposit ON public.deposits CASCADE;
DROP TRIGGER IF EXISTS update_balance_on_deposit ON public.deposits CASCADE;
DROP TRIGGER IF EXISTS update_balance_on_investment ON public.investments CASCADE;
DROP TRIGGER IF EXISTS update_balance_on_withdrawal ON public.withdrawals CASCADE;
DROP TRIGGER IF EXISTS update_balance_on_bonus ON public.referral_bonuses CASCADE;

-- Drop functions safely
DROP FUNCTION IF EXISTS public.handle_new_user() CASCADE;
DROP FUNCTION IF EXISTS public.handle_first_deposit() CASCADE;
DROP FUNCTION IF EXISTS public.update_balance_on_deposit() CASCADE;
DROP FUNCTION IF EXISTS public.update_balance_on_investment() CASCADE;
DROP FUNCTION IF EXISTS public.update_balance_on_withdrawal() CASCADE;
DROP FUNCTION IF EXISTS public.update_balance_on_bonus() CASCADE;
DROP FUNCTION IF EXISTS public.purchase_robot(uuid, text, numeric, integer) CASCADE;
DROP FUNCTION IF EXISTS public.generate_referral_code() CASCADE;

-- Drop tables safely
DROP TABLE IF EXISTS public.referral_bonuses CASCADE;
DROP TABLE IF EXISTS public.investments CASCADE;
DROP TABLE IF EXISTS public.withdrawals CASCADE;
DROP TABLE IF EXISTS public.deposits CASCADE;
DROP TABLE IF EXISTS public.profiles CASCADE;

-- 2. CREATE TABLES
-- Tabela de Perfis
CREATE TABLE public.profiles (
    user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email text UNIQUE,
    full_name text,
    cpf text UNIQUE,
    phone text,
    referral_code text UNIQUE NOT NULL,
    referred_by uuid REFERENCES public.profiles(user_id) ON DELETE SET NULL,
    balance numeric NOT NULL DEFAULT 0.00,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Usuários podem ver seus próprios perfis" ON public.profiles FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Permitir leitura pública de código de referência" ON public.profiles FOR SELECT USING (true);

-- Tabela de Depósitos
CREATE TABLE public.deposits (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    amount numeric NOT NULL,
    status text NOT NULL DEFAULT 'completed',
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.deposits ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Usuários podem ver seus próprios depósitos" ON public.deposits FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Usuários podem criar depósitos" ON public.deposits FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Tabela de Investimentos
CREATE TABLE public.investments (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    robot_id text NOT NULL,
    amount numeric NOT NULL,
    status text NOT NULL DEFAULT 'active',
    start_date timestamptz NOT NULL DEFAULT now(),
    end_date timestamptz NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.investments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Usuários podem ver seus próprios investimentos" ON public.investments FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Usuários podem criar investimentos" ON public.investments FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Tabela de Saques
CREATE TABLE public.withdrawals (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    amount numeric NOT NULL,
    wallet_address text NOT NULL,
    status text NOT NULL DEFAULT 'pending',
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.withdrawals ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Usuários podem ver seus próprios saques" ON public.withdrawals FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Usuários podem criar saques" ON public.withdrawals FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Tabela de Bônus de Referência
CREATE TABLE public.referral_bonuses (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    amount numeric NOT NULL,
    reason text NOT NULL,
    source_user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.referral_bonuses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Usuários podem ver seus próprios bônus" ON public.referral_bonuses FOR SELECT USING (auth.uid() = user_id);

-- 3. CREATE FUNCTIONS
-- Função para gerar código de referência único
CREATE OR REPLACE FUNCTION public.generate_referral_code()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
    new_code text;
    is_duplicate boolean;
BEGIN
    LOOP
        new_code := upper(substr(md5(random()::text), 1, 8));
        SELECT EXISTS (SELECT 1 FROM public.profiles WHERE referral_code = new_code) INTO is_duplicate;
        IF NOT is_duplicate THEN
            RETURN new_code;
        END IF;
    END LOOP;
END;
$$;

-- Função para criar perfil de novo usuário
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
    referrer_id uuid;
BEGIN
    -- Encontrar o referrer_id a partir do código de referência, se fornecido
    IF NEW.raw_user_meta_data->>'referral_code' IS NOT NULL AND NEW.raw_user_meta_data->>'referral_code' <> '' THEN
        SELECT user_id INTO referrer_id FROM public.profiles WHERE referral_code = (NEW.raw_user_meta_data->>'referral_code');
    END IF;

    -- Inserir novo perfil
    INSERT INTO public.profiles (user_id, email, full_name, cpf, phone, referral_code, referred_by)
    VALUES (
        NEW.id,
        NEW.email,
        NEW.raw_user_meta_data->>'full_name',
        NEW.raw_user_meta_data->>'cpf',
        NEW.raw_user_meta_data->>'phone',
        public.generate_referral_code(),
        referrer_id
    );

    -- Conceder bônus de R$10 para o novo usuário por se cadastrar
    INSERT INTO public.referral_bonuses (user_id, amount, reason, source_user_id)
    VALUES (NEW.id, 10.00, 'Bônus de cadastro', NEW.id);

    RETURN NEW;
END;
$$;

-- Função para conceder bônus no primeiro depósito
CREATE OR REPLACE FUNCTION public.handle_first_deposit()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
    deposit_count integer;
    referrer_profile record;
BEGIN
    -- Verifica se é o primeiro depósito do usuário
    SELECT count(*) INTO deposit_count FROM public.deposits WHERE user_id = NEW.user_id;

    IF deposit_count = 1 THEN
        -- Encontra quem indicou o usuário que fez o depósito
        SELECT p.user_id, p.referred_by INTO referrer_profile FROM public.profiles p WHERE p.user_id = NEW.user_id;

        -- Se houver um indicador, concede o bônus de R$10 a ele
        IF referrer_profile.referred_by IS NOT NULL THEN
            INSERT INTO public.referral_bonuses (user_id, amount, reason, source_user_id)
            VALUES (referrer_profile.referred_by, 10.00, 'Bônus de indicação', NEW.user_id);
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

-- Funções para atualizar o saldo
CREATE OR REPLACE FUNCTION public.update_balance_on_deposit() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = 'public' AS $$ BEGIN UPDATE public.profiles SET balance = balance + NEW.amount WHERE user_id = NEW.user_id; RETURN NEW; END; $$;
CREATE OR REPLACE FUNCTION public.update_balance_on_investment() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = 'public' AS $$ BEGIN UPDATE public.profiles SET balance = balance - NEW.amount WHERE user_id = NEW.user_id; RETURN NEW; END; $$;
CREATE OR REPLACE FUNCTION public.update_balance_on_withdrawal() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = 'public' AS $$ BEGIN UPDATE public.profiles SET balance = balance - NEW.amount WHERE user_id = NEW.user_id; RETURN NEW; END; $$;
CREATE OR REPLACE FUNCTION public.update_balance_on_bonus() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = 'public' AS $$ BEGIN UPDATE public.profiles SET balance = balance + NEW.amount WHERE user_id = NEW.user_id; RETURN NEW; END; $$;

-- Função para comprar robô
CREATE OR REPLACE FUNCTION public.purchase_robot(p_user_id uuid, p_robot_id text, p_amount numeric, p_period_days integer)
RETURNS table(success boolean, message text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
    current_balance numeric;
BEGIN
    SELECT balance INTO current_balance FROM public.profiles WHERE user_id = p_user_id;

    IF current_balance < p_amount THEN
        RETURN QUERY SELECT false, 'Saldo insuficiente para realizar este investimento.';
        RETURN;
    END IF;

    INSERT INTO public.investments (user_id, robot_id, amount, end_date)
    VALUES (p_user_id, p_robot_id, p_amount, now() + (p_period_days || ' days')::interval);

    RETURN QUERY SELECT true, 'Investimento realizado com sucesso!';
END;
$$;


-- 4. CREATE TRIGGERS
-- Gatilho para criar perfil de usuário
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Gatilho para bônus de primeiro depósito
CREATE TRIGGER on_first_deposit
AFTER INSERT ON public.deposits
FOR EACH ROW EXECUTE FUNCTION public.handle_first_deposit();

-- Gatilhos para atualizar saldo
CREATE TRIGGER update_balance_on_deposit AFTER INSERT ON public.deposits FOR EACH ROW EXECUTE FUNCTION public.update_balance_on_deposit();
CREATE TRIGGER update_balance_on_investment AFTER INSERT ON public.investments FOR EACH ROW EXECUTE FUNCTION public.update_balance_on_investment();
CREATE TRIGGER update_balance_on_withdrawal AFTER INSERT ON public.withdrawals FOR EACH ROW EXECUTE FUNCTION public.update_balance_on_withdrawal();
CREATE TRIGGER update_balance_on_bonus AFTER INSERT ON public.referral_bonuses FOR EACH ROW EXECUTE FUNCTION public.update_balance_on_bonus();
