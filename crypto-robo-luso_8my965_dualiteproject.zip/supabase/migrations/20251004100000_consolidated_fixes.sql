-- =================================================================
-- MIGRATION SCRIPT: Correção do Sistema de Afiliados e Segurança
-- =================================================================
-- Este script resolve os seguintes problemas:
-- 1. Garante que cada usuário receba um código de referência único no cadastro.
-- 2. Corrige o fluxo de atribuição de bônus de referência.
-- 3. Resolve os avisos de segurança "Function Search Path Mutable".
-- =================================================================

-- 1. Limpeza de funções e gatilhos antigos para evitar conflitos
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user();
DROP FUNCTION IF EXISTS public.generate_referral_code();
DROP FUNCTION IF EXISTS public.handle_first_deposit();
DROP FUNCTION IF EXISTS public.purchase_robot(uuid, text, numeric, integer);


-- 2. Função para gerar um código de referência único e aleatório
CREATE OR REPLACE FUNCTION public.generate_referral_code()
RETURNS TEXT AS $$
DECLARE
  new_code TEXT;
  is_duplicate BOOLEAN;
BEGIN
  LOOP
    new_code := upper(substr(md5(random()::text), 0, 9)); -- Gera um código de 8 caracteres
    SELECT EXISTS (SELECT 1 FROM public.profiles WHERE referral_code = new_code) INTO is_duplicate;
    IF NOT is_duplicate THEN
      RETURN new_code;
    END IF;
  END LOOP;
END;
$$ LANGUAGE plpgsql VOLATILE SECURITY DEFINER
SET search_path = 'public';


-- 3. Função principal para lidar com novos usuários
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  referrer_id_var UUID;
  referrer_profile RECORD;
BEGIN
  -- Tenta encontrar o referrer_id a partir do código de referência fornecido no cadastro
  IF new.raw_user_meta_data->>'referral_code' IS NOT NULL AND new.raw_user_meta_data->>'referral_code' != '' THEN
    SELECT user_id INTO referrer_id_var FROM public.profiles WHERE referral_code = (new.raw_user_meta_data->>'referral_code');
  END IF;

  -- Insere o novo perfil de usuário
  INSERT INTO public.profiles (user_id, email, full_name, cpf, phone, referred_by, referral_code)
  VALUES (
    new.id,
    new.email,
    new.raw_user_meta_data->>'full_name',
    new.raw_user_meta_data->>'cpf',
    new.raw_user_meta_data->>'phone',
    referrer_id_var,
    public.generate_referral_code()
  );

  -- Se o usuário foi indicado, ele ganha um bônus de cadastro
  IF referrer_id_var IS NOT NULL THEN
    INSERT INTO public.referral_bonuses (user_id, amount, reason, source_user_id)
    VALUES (new.id, 10, 'Bônus de cadastro por indicação', referrer_id_var);
  END IF;

  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = 'public';


-- 4. Função para lidar com o primeiro depósito (bônus para quem indicou)
CREATE OR REPLACE FUNCTION public.handle_first_deposit()
RETURNS TRIGGER AS $$
DECLARE
  referrer_id_var UUID;
BEGIN
  -- Verifica se é o primeiro depósito do usuário
  IF (SELECT count(*) FROM public.deposits WHERE user_id = new.user_id) = 1 THEN
    -- Busca quem indicou este usuário
    SELECT referred_by INTO referrer_id_var FROM public.profiles WHERE user_id = new.user_id;
    
    -- Se houver um indicador, dá o bônus a ele
    IF referrer_id_var IS NOT NULL THEN
      INSERT INTO public.referral_bonuses (user_id, amount, reason, source_user_id)
      VALUES (referrer_id_var, 10, 'Bônus de indicação', new.user_id);
    END IF;
  END IF;
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER
SET search_path = 'public';


-- 5. Função para comprar robô (com segurança aprimorada)
CREATE OR REPLACE FUNCTION public.purchase_robot(
  p_user_id uuid,
  p_robot_id text,
  p_amount numeric,
  p_period_days integer
)
RETURNS TABLE (success boolean, message text)
LANGUAGE plpgsql
AS $$
DECLARE
  v_total_deposits numeric;
  v_total_withdrawals numeric;
  v_total_investments numeric;
  v_total_bonuses numeric;
  v_current_balance numeric;
BEGIN
  -- Calculate current balance
  SELECT COALESCE(sum(amount), 0) INTO v_total_deposits FROM public.deposits WHERE user_id = p_user_id;
  SELECT COALESCE(sum(amount), 0) INTO v_total_withdrawals FROM public.withdrawals WHERE user_id = p_user_id AND status = 'completed';
  SELECT COALESCE(sum(amount), 0) INTO v_total_investments FROM public.investments WHERE user_id = p_user_id;
  SELECT COALESCE(sum(amount), 0) INTO v_total_bonuses FROM public.referral_bonuses WHERE user_id = p_user_id;
  
  v_current_balance := (v_total_deposits + v_total_bonuses) - v_total_withdrawals - v_total_investments;
  
  -- Check if balance is sufficient
  IF v_current_balance < p_amount THEN
    RETURN QUERY SELECT false, 'Saldo insuficiente para realizar este investimento.';
    RETURN;
  END IF;
  
  -- Insert the new investment
  INSERT INTO public.investments (user_id, robot_id, amount, end_date)
  VALUES (p_user_id, p_robot_id, p_amount, now() + (p_period_days || ' days')::interval);
  
  RETURN QUERY SELECT true, 'Investimento realizado com sucesso!';
END;
$$ SECURITY DEFINER
SET search_path = 'public';


-- 6. Recriação dos gatilhos
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();

CREATE TRIGGER on_first_deposit
  AFTER INSERT ON public.deposits
  FOR EACH ROW EXECUTE PROCEDURE public.handle_first_deposit();
