-- Drop triggers first to remove dependencies
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP TRIGGER IF EXISTS on_first_deposit ON public.deposits;

-- Drop functions
DROP FUNCTION IF EXISTS public.handle_new_user();
DROP FUNCTION IF EXISTS public.handle_first_deposit();
DROP FUNCTION IF EXISTS public.generate_referral_code();
DROP FUNCTION IF EXISTS public.purchase_robot(uuid, text, numeric, integer);


-- Recreate function: generate_referral_code()
CREATE OR REPLACE FUNCTION public.generate_referral_code()
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  new_code TEXT;
  is_duplicate BOOLEAN;
BEGIN
  LOOP
    new_code := upper(substr(md5(random()::text), 0, 9)); -- Gera um código de 8 caracteres
    SELECT EXISTS (SELECT 1 FROM public.profiles WHERE referral_code = new_code) INTO is_duplicate;
    IF NOT is_duplicate THEN
      RETURN new_code;
    END IF;
  END LOOP;
END;
$$;


-- Recreate function: handle_new_user()
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  referrer_id_var UUID;
  referral_code_var TEXT;
BEGIN
  -- Extrai o código de referência dos metadados do novo usuário
  referral_code_var := new.raw_user_meta_data->>'referral_code';

  -- Encontra o ID do usuário que indicou (se o código for válido)
  IF referral_code_var IS NOT NULL AND referral_code_var != '' THEN
    SELECT user_id INTO referrer_id_var FROM public.profiles WHERE referral_code = referral_code_var;
  END IF;

  -- Insere o novo perfil
  INSERT INTO public.profiles (user_id, email, full_name, cpf, phone, referred_by)
  VALUES (
    new.id,
    new.email,
    new.raw_user_meta_data->>'full_name',
    new.raw_user_meta_data->>'cpf',
    new.raw_user_meta_data->>'phone',
    referrer_id_var
  );

  -- Adiciona bônus de R$10 para o novo usuário por se cadastrar
  INSERT INTO public.referral_bonuses (user_id, amount, reason)
  VALUES (new.id, 10, 'Bônus de cadastro');

  RETURN new;
END;
$$;


-- Recreate function: handle_first_deposit()
CREATE OR REPLACE FUNCTION public.handle_first_deposit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
    referrer_id_var UUID;
    deposit_count INT;
BEGIN
    -- Verifica se este é o primeiro depósito do usuário
    SELECT count(*) INTO deposit_count FROM public.deposits WHERE user_id = NEW.user_id;

    IF deposit_count = 1 THEN
        -- Encontra quem indicou o usuário
        SELECT referred_by INTO referrer_id_var FROM public.profiles WHERE user_id = NEW.user_id;

        -- Se houver um indicador, adiciona o bônus de R$10 para ele
        IF referrer_id_var IS NOT NULL THEN
            INSERT INTO public.referral_bonuses (user_id, amount, reason, source_user_id)
            VALUES (referrer_id_var, 10, 'Bônus de indicação', NEW.user_id);
        END IF;
    END IF;

    RETURN NEW;
END;
$$;


-- Recreate function: purchase_robot()
CREATE OR REPLACE FUNCTION public.purchase_robot(
  p_user_id uuid,
  p_robot_id text,
  p_amount numeric,
  p_period_days integer
)
RETURNS TABLE (success boolean, message text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_total_deposits numeric;
  v_total_bonuses numeric;
  v_total_withdrawals numeric;
  v_total_investments numeric;
  v_current_balance numeric;
BEGIN
  -- Calcula o saldo atual
  SELECT COALESCE(SUM(amount), 0) INTO v_total_deposits FROM public.deposits WHERE user_id = p_user_id AND status = 'completed';
  SELECT COALESCE(SUM(amount), 0) INTO v_total_bonuses FROM public.referral_bonuses WHERE user_id = p_user_id;
  SELECT COALESCE(SUM(amount), 0) INTO v_total_withdrawals FROM public.withdrawals WHERE user_id = p_user_id AND status = 'completed';
  SELECT COALESCE(SUM(amount), 0) INTO v_total_investments FROM public.investments WHERE user_id = p_user_id;

  v_current_balance := v_total_deposits + v_total_bonuses - v_total_withdrawals - v_total_investments;

  -- Verifica se o saldo é suficiente
  IF v_current_balance < p_amount THEN
    RETURN QUERY SELECT FALSE, 'Saldo insuficiente para realizar este investimento.';
    RETURN;
  END IF;

  -- Insere o novo investimento
  INSERT INTO public.investments (user_id, robot_id, amount, end_date)
  VALUES (p_user_id, p_robot_id, p_amount, now() + (p_period_days || ' days')::interval);

  RETURN QUERY SELECT TRUE, 'Investimento realizado com sucesso!';
END;
$$;

-- Recreate triggers
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();

CREATE TRIGGER on_first_deposit
  AFTER INSERT ON public.deposits
  FOR EACH ROW EXECUTE PROCEDURE public.handle_first_deposit();
