/*
  ## Operation: Secure Database Functions
  [This script secures existing PostgreSQL functions by explicitly setting the `search_path`. This is a recommended security practice by Supabase to prevent potential schema-hijacking attacks.]

  ## Query Description:
  - This operation will ALTER and REPLACE three existing functions: `handle_new_user`, `handle_first_deposit_bonus`, and `purchase_robot`.
  - The core logic of the functions remains unchanged. The only addition is `SET search_path = 'public'` to each function definition.
  - This change is non-destructive and has no impact on existing data. It enhances the security of your database.

  ## Metadata:
  - Schema-Category: "Security"
  - Impact-Level: "Low"
  - Requires-Backup: false
  - Reversible: true (by removing the SET search_path line)

  ## Security Implications:
  - RLS Status: Unchanged
  - Policy Changes: No
  - Auth Requirements: This script should be run by a user with sufficient privileges (e.g., postgres).
*/

-- Securing the 'handle_new_user' trigger function
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  signup_bonus_amount numeric := 10;
  referrer_id_val uuid;
  new_referral_code text;
  referred_by_code text;
BEGIN
  -- Extract referral code from metadata if it exists
  referred_by_code := new.raw_user_meta_data->>'referral_code';

  -- Find the referrer's user_id based on the code
  IF referred_by_code IS NOT NULL THEN
    SELECT user_id INTO referrer_id_val FROM public.profiles WHERE referral_code = referred_by_code LIMIT 1;
  END IF;

  -- Generate a unique referral code for the new user
  new_referral_code := substr(md5(random()::text || clock_timestamp()::text), 1, 8);

  -- Insert into public.profiles
  INSERT INTO public.profiles (user_id, email, full_name, cpf, phone, referral_code, referred_by)
  VALUES (
    new.id,
    new.email,
    new.raw_user_meta_data->>'full_name',
    new.raw_user_meta_data->>'cpf',
    new.raw_user_meta_data->>'phone',
    new_referral_code,
    referrer_id_val
  );

  -- Grant a bonus to the new user for signing up
  INSERT INTO public.referral_bonuses (user_id, amount, reason)
  VALUES (new.id, signup_bonus_amount, 'Bônus de cadastro');

  RETURN new;
END;
$$;


-- Securing the 'handle_first_deposit_bonus' trigger function
CREATE OR REPLACE FUNCTION public.handle_first_deposit_bonus()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  deposit_count integer;
  referrer_id_val uuid;
  referral_bonus_amount numeric := 10;
BEGIN
  -- Check if this is the user's first deposit (count will be 1 because the trigger runs AFTER insert)
  SELECT count(*) INTO deposit_count FROM public.deposits WHERE user_id = NEW.user_id;

  IF deposit_count = 1 THEN
    -- Find who referred this user
    SELECT referred_by INTO referrer_id_val FROM public.profiles WHERE user_id = NEW.user_id;

    -- If there's a referrer, give them a bonus for the first deposit of their referral
    IF referrer_id_val IS NOT NULL THEN
      INSERT INTO public.referral_bonuses (user_id, amount, reason, source_user_id)
      VALUES (referrer_id_val, referral_bonus_amount, 'Bônus de indicação por depósito', NEW.user_id);
    END IF;
  END IF;

  RETURN NEW;
END;
$$;


-- Securing the 'purchase_robot' RPC function
CREATE OR REPLACE FUNCTION public.purchase_robot(p_robot_id text, p_amount numeric)
RETURNS TABLE(success boolean, message text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  v_user_id uuid := auth.uid();
  v_total_deposits numeric;
  v_total_withdrawals numeric;
  v_total_investments numeric;
  v_total_bonuses numeric;
  v_current_balance numeric;
  v_robot_period int;
BEGIN
  -- Determine robot period based on ID
  CASE p_robot_id
      WHEN '1' THEN v_robot_period := 30;
      ELSE v_robot_period := 45;
  END CASE;

  -- Calculate current balance
  SELECT COALESCE(SUM(amount), 0) INTO v_total_deposits FROM public.deposits WHERE user_id = v_user_id;
  SELECT COALESCE(SUM(amount), 0) INTO v_total_withdrawals FROM public.withdrawals WHERE user_id = v_user_id AND status = 'completed';
  SELECT COALESCE(SUM(amount), 0) INTO v_total_investments FROM public.investments WHERE user_id = v_user_id;
  SELECT COALESCE(SUM(amount), 0) INTO v_total_bonuses FROM public.referral_bonuses WHERE user_id = v_user_id;
  
  v_current_balance := v_total_deposits + v_total_bonuses - v_total_withdrawals - v_total_investments;

  -- Check if balance is sufficient
  IF v_current_balance < p_amount THEN
    RETURN QUERY SELECT false, 'Saldo insuficiente para realizar este investimento.';
    RETURN;
  END IF;

  -- Insert the new investment
  INSERT INTO public.investments (user_id, robot_id, amount, end_date)
  VALUES (v_user_id, p_robot_id, p_amount, now() + (v_robot_period || ' days')::interval);
  
  RETURN QUERY SELECT true, 'Investimento realizado com sucesso!';
END;
$$;
