-- Drop dependent triggers first to avoid errors
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP TRIGGER IF EXISTS on_first_deposit ON public.deposits;
DROP TRIGGER IF EXISTS update_balance_on_deposit ON public.deposits;
DROP TRIGGER IF EXISTS update_balance_on_investment ON public.investments;
DROP TRIGGER IF EXISTS update_balance_on_withdrawal ON public.withdrawals;
DROP TRIGGER IF EXISTS update_balance_on_bonus ON public.referral_bonuses;

-- Drop all functions
DROP FUNCTION IF EXISTS public.handle_new_user();
DROP FUNCTION IF EXISTS public.generate_referral_code();
DROP FUNCTION IF EXISTS public.handle_first_deposit();
DROP FUNCTION IF EXISTS public.update_balance_on_deposit();
DROP FUNCTION IF EXISTS public.update_balance_on_investment();
DROP FUNCTION IF EXISTS public.update_balance_on_withdrawal();
DROP FUNCTION IF EXISTS public.update_balance_on_bonus();
DROP FUNCTION IF EXISTS public.purchase_robot(uuid, text, numeric, integer);

-- Recreate function to generate a unique referral code
CREATE OR REPLACE FUNCTION public.generate_referral_code()
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  new_code TEXT;
  is_duplicate BOOLEAN;
BEGIN
  LOOP
    new_code := upper(substr(md5(random()::text), 0, 7));
    SELECT EXISTS (SELECT 1 FROM public.profiles WHERE referral_code = new_code) INTO is_duplicate;
    EXIT WHEN NOT is_duplicate;
  END LOOP;
  RETURN new_code;
END;
$$;

-- Recreate function to handle new user creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  referrer_id UUID;
BEGIN
  IF NEW.raw_user_meta_data->>'referral_code' IS NOT NULL THEN
    SELECT user_id INTO referrer_id FROM public.profiles WHERE referral_code = (NEW.raw_user_meta_data->>'referral_code');
  END IF;

  INSERT INTO public.profiles (user_id, email, full_name, cpf, phone, referred_by, referral_code)
  VALUES (
    NEW.id,
    NEW.email,
    NEW.raw_user_meta_data->>'full_name',
    NEW.raw_user_meta_data->>'cpf',
    NEW.raw_user_meta_data->>'phone',
    referrer_id,
    public.generate_referral_code()
  );

  INSERT INTO public.referral_bonuses (user_id, amount, reason)
  VALUES (NEW.id, 10, 'Bônus de cadastro');

  RETURN NEW;
END;
$$;

-- Recreate function to handle first deposit bonus
CREATE OR REPLACE FUNCTION public.handle_first_deposit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  referrer_profile RECORD;
  deposit_count INT;
BEGIN
  SELECT count(*) INTO deposit_count FROM public.deposits WHERE user_id = NEW.user_id;

  IF deposit_count = 1 THEN
    SELECT p.referred_by INTO referrer_profile
    FROM public.profiles p
    WHERE p.user_id = NEW.user_id AND p.referred_by IS NOT NULL;

    IF FOUND THEN
      INSERT INTO public.referral_bonuses (user_id, amount, reason, source_user_id)
      VALUES (referrer_profile.referred_by, 10, 'Bônus de indicação', NEW.user_id);
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

-- Recreate balance update functions
CREATE OR REPLACE FUNCTION public.update_balance_on_deposit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  UPDATE public.profiles SET balance = balance + NEW.amount WHERE user_id = NEW.user_id;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_balance_on_investment()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  UPDATE public.profiles SET balance = balance - NEW.amount WHERE user_id = NEW.user_id;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_balance_on_withdrawal()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  IF NEW.status = 'pending' THEN
    UPDATE public.profiles SET balance = balance - NEW.amount WHERE user_id = NEW.user_id;
  END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_balance_on_bonus()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  UPDATE public.profiles SET balance = balance + NEW.amount WHERE user_id = NEW.user_id;
  RETURN NEW;
END;
$$;

-- Recreate robot purchase function
CREATE OR REPLACE FUNCTION public.purchase_robot(
  p_user_id uuid,
  p_robot_id text,
  p_amount numeric,
  p_period_days integer
)
RETURNS TABLE (success boolean, message text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  user_balance NUMERIC;
BEGIN
  SELECT balance INTO user_balance FROM public.profiles WHERE user_id = p_user_id;

  IF user_balance < p_amount THEN
    RETURN QUERY SELECT false, 'Saldo insuficiente para realizar este investimento.';
    RETURN;
  END IF;

  INSERT INTO public.investments (user_id, robot_id, amount, end_date)
  VALUES (p_user_id, p_robot_id, p_amount, now() + (p_period_days || ' days')::interval);

  RETURN QUERY SELECT true, 'Investimento realizado com sucesso!';
END;
$$;

-- Recreate all triggers
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE TRIGGER on_first_deposit
  AFTER INSERT ON public.deposits
  FOR EACH ROW EXECUTE FUNCTION public.handle_first_deposit();

CREATE TRIGGER update_balance_on_deposit
  AFTER INSERT ON public.deposits
  FOR EACH ROW EXECUTE FUNCTION public.update_balance_on_deposit();

CREATE TRIGGER update_balance_on_investment
  AFTER INSERT ON public.investments
  FOR EACH ROW EXECUTE FUNCTION public.update_balance_on_investment();

CREATE TRIGGER update_balance_on_withdrawal
  AFTER INSERT ON public.withdrawals
  FOR EACH ROW EXECUTE FUNCTION public.update_balance_on_withdrawal();

CREATE TRIGGER update_balance_on_bonus
  AFTER INSERT ON public.referral_bonuses
  FOR EACH ROW EXECUTE FUNCTION public.update_balance_on_bonus();
