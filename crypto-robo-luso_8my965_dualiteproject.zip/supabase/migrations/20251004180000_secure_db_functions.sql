-- This script secures all custom functions by setting a non-mutable search_path.
-- This resolves the "Function Search Path Mutable" security advisory.

-- Function to generate a unique referral code
CREATE OR REPLACE FUNCTION public.generate_referral_code()
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  new_code TEXT;
  is_unique BOOLEAN := false;
BEGIN
  SET search_path = public;
  WHILE NOT is_unique LOOP
    new_code := upper(substr(md5(random()::text), 0, 7)); -- 6-character code
    SELECT NOT EXISTS (SELECT 1 FROM profiles WHERE referral_code = new_code) INTO is_unique;
  END LOOP;
  RETURN new_code;
END;
$$;

-- Function to handle new user creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    referrer_id UUID;
BEGIN
    SET search_path = public;
    -- Find referrer if a valid code was provided
    IF NEW.raw_user_meta_data->>'referral_code' IS NOT NULL THEN
        SELECT user_id INTO referrer_id FROM profiles WHERE referral_code = (NEW.raw_user_meta_data->>'referral_code');
    END IF;

    -- Insert into public.profiles
    INSERT INTO public.profiles (user_id, email, full_name, cpf, phone, referred_by, referral_code)
    VALUES (
        NEW.id,
        NEW.email,
        NEW.raw_user_meta_data->>'full_name',
        NEW.raw_user_meta_data->>'cpf',
        NEW.raw_user_meta_data->>'phone',
        referrer_id,
        generate_referral_code()
    );

    -- Grant R$10 bonus to the new user for signing up
    INSERT INTO public.referral_bonuses (user_id, amount, reason)
    VALUES (NEW.id, 10, 'Bônus de cadastro');

    RETURN NEW;
END;
$$;

-- Function to handle first deposit bonus
CREATE OR REPLACE FUNCTION public.handle_first_deposit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    referrer_profile RECORD;
BEGIN
    SET search_path = public;
    -- Check if this is the user's first deposit
    IF (SELECT count(*) FROM public.deposits WHERE user_id = NEW.user_id) = 1 THEN
        -- Find who referred this user
        SELECT p.user_id, p.referred_by INTO referrer_profile
        FROM public.profiles p
        WHERE p.user_id = NEW.user_id;

        -- If the user was referred, grant R$10 bonus to the referrer
        IF referrer_profile.referred_by IS NOT NULL THEN
            INSERT INTO public.referral_bonuses (user_id, amount, reason, source_user_id)
            VALUES (referrer_profile.referred_by, 10, 'Bônus de indicação', NEW.user_id);
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

-- Function to update balance on deposit
CREATE OR REPLACE FUNCTION public.update_balance_on_deposit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    SET search_path = public;
    UPDATE public.profiles
    SET balance = balance + NEW.amount
    WHERE user_id = NEW.user_id;
    RETURN NEW;
END;
$$;

-- Function to update balance on investment
CREATE OR REPLACE FUNCTION public.update_balance_on_investment()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    SET search_path = public;
    UPDATE public.profiles
    SET balance = balance - NEW.amount
    WHERE user_id = NEW.user_id;
    RETURN NEW;
END;
$$;

-- Function to update balance on withdrawal
CREATE OR REPLACE FUNCTION public.update_balance_on_withdrawal()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    SET search_path = public;
    UPDATE public.profiles
    SET balance = balance - NEW.amount
    WHERE user_id = NEW.user_id;
    RETURN NEW;
END;
$$;

-- Function to update balance on bonus
CREATE OR REPLACE FUNCTION public.update_balance_on_bonus()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    SET search_path = public;
    UPDATE public.profiles
    SET balance = balance + NEW.amount
    WHERE user_id = NEW.user_id;
    RETURN NEW;
END;
$$;


-- Function to purchase a robot
CREATE OR REPLACE FUNCTION public.purchase_robot(
  p_user_id uuid,
  p_robot_id text,
  p_amount numeric,
  p_period_days integer
)
RETURNS TABLE (success boolean, message text)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_current_balance numeric;
  v_transaction_fee numeric := p_amount * 0.025; -- 2.5% fee
  v_net_investment numeric := p_amount - v_transaction_fee;
BEGIN
  SET search_path = public;
  -- Get current balance directly from profiles table
  SELECT balance INTO v_current_balance FROM public.profiles WHERE user_id = p_user_id;

  -- Check if balance is sufficient
  IF v_current_balance < p_amount THEN
    RETURN QUERY SELECT false, 'Saldo insuficiente para realizar este investimento.';
    RETURN;
  END IF;

  -- Insert the new investment with the net amount
  INSERT INTO public.investments (user_id, robot_id, amount, end_date)
  VALUES (p_user_id, p_robot_id, v_net_investment, now() + (p_period_days || ' days')::interval);

  RETURN QUERY SELECT true, 'Investimento realizado com sucesso!';
END;
$$;

-- Grant execute permissions to the 'authenticated' role for the functions
GRANT EXECUTE ON FUNCTION public.purchase_robot(uuid, text, numeric, integer) TO authenticated;
GRANT EXECUTE ON FUNCTION public.generate_referral_code() TO authenticated;
