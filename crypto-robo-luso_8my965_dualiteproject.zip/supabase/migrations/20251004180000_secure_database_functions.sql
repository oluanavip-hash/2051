-- This script recreates all functions with enhanced security settings to resolve warnings.

-- Function to generate a unique referral code
CREATE OR REPLACE FUNCTION public.generate_referral_code()
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  new_code TEXT;
  is_unique BOOLEAN := false;
BEGIN
  WHILE NOT is_unique LOOP
    new_code := upper(substr(md5(random()::text), 0, 9)); -- 8-character code
    PERFORM 1 FROM public.profiles WHERE referral_code = new_code;
    IF NOT FOUND THEN
      is_unique := true;
    END IF;
  END LOOP;
  RETURN new_code;
END;
$$;

-- Trigger function to handle new user creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
    referred_by_user_id UUID;
BEGIN
    -- Find the user who referred this new user, if a valid code was provided
    IF NEW.raw_user_meta_data->>'referral_code' IS NOT NULL THEN
        SELECT user_id INTO referred_by_user_id
        FROM public.profiles
        WHERE referral_code = (NEW.raw_user_meta_data->>'referral_code');
    END IF;

    -- Insert into public.profiles
    INSERT INTO public.profiles (user_id, email, full_name, cpf, phone, referred_by, referral_code)
    VALUES (
        NEW.id,
        NEW.email,
        NEW.raw_user_meta_data->>'full_name',
        NEW.raw_user_meta_data->>'cpf',
        NEW.raw_user_meta_data->>'phone',
        referred_by_user_id,
        public.generate_referral_code()
    );

    -- Grant a bonus to the new user for signing up
    INSERT INTO public.referral_bonuses (user_id, amount, reason)
    VALUES (NEW.id, 10, 'Bônus de cadastro');

    RETURN NEW;
END;
$$;

-- Trigger function to update balance on new deposit
CREATE OR REPLACE FUNCTION public.update_balance_on_deposit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  UPDATE public.profiles
  SET balance = balance + NEW.amount
  WHERE user_id = NEW.user_id;
  RETURN NEW;
END;
$$;

-- Trigger function to update balance on new investment
CREATE OR REPLACE FUNCTION public.update_balance_on_investment()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  UPDATE public.profiles
  SET balance = balance - NEW.amount
  WHERE user_id = NEW.user_id;
  RETURN NEW;
END;
$$;

-- Trigger function to update balance on withdrawal request
CREATE OR REPLACE FUNCTION public.update_balance_on_withdrawal()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.profiles
    SET balance = balance - NEW.amount
    WHERE user_id = NEW.user_id;
  END IF;
  RETURN NEW;
END;
$$;

-- Trigger function to update balance on new bonus
CREATE OR REPLACE FUNCTION public.update_balance_on_bonus()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  UPDATE public.profiles
  SET balance = balance + NEW.amount
  WHERE user_id = NEW.user_id;
  RETURN NEW;
END;
$$;

-- Trigger function to handle first deposit bonus
CREATE OR REPLACE FUNCTION public.handle_first_deposit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
    deposit_count INT;
    referrer_id UUID;
BEGIN
    -- Check if this is the user's first deposit
    SELECT count(*) INTO deposit_count
    FROM public.deposits
    WHERE user_id = NEW.user_id;

    -- If it's the first deposit, check for a referrer and grant bonus
    IF deposit_count = 1 THEN
        SELECT referred_by INTO referrer_id
        FROM public.profiles
        WHERE user_id = NEW.user_id;

        IF referrer_id IS NOT NULL THEN
            -- Grant bonus to the referrer
            INSERT INTO public.referral_bonuses (user_id, amount, reason, source_user_id)
            VALUES (referrer_id, 10, 'Bônus de indicação', NEW.user_id);
        END IF;
    END IF;

    RETURN NEW;
END;
$$;


-- Function to purchase a robot, ensuring user has enough balance.
CREATE OR REPLACE FUNCTION public.purchase_robot(p_user_id uuid, p_robot_id text, p_amount numeric, p_period_days integer)
RETURNS TABLE(success boolean, message text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  v_current_balance numeric;
BEGIN
  -- Get current balance directly from profiles table
  SELECT balance INTO v_current_balance FROM public.profiles WHERE user_id = p_user_id;

  -- Check if balance is sufficient
  IF v_current_balance < p_amount THEN
    RETURN QUERY SELECT false, 'Saldo insuficiente para realizar este investimento.';
    RETURN;
  END IF;

  -- Insert the new investment
  INSERT INTO public.investments (user_id, robot_id, amount, end_date)
  VALUES (p_user_id, p_robot_id, p_amount, now() + (p_period_days || ' days')::interval);

  RETURN QUERY SELECT true, 'Investimento realizado com sucesso!';
END;
$$;
