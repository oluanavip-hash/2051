import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const BULLSPAY_BASE_URL = 'https://api.bullbank.com.br';
const AUTH_URL = `${BULLSPAY_BASE_URL}/oauth/token`;
const PIX_CHARGE_URL = `${BULLSPAY_BASE_URL}/v1/pix/charges`;

async function getAuthToken(clientId: string, clientSecret: string) {
  console.log('Obtendo token de autenticação da Bullspay...');
  const response = await fetch(AUTH_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      grant_type: 'client_credentials',
      client_id: clientId,
      client_secret: clientSecret,
    }),
  });

  const responseBodyText = await response.text();
  if (!response.ok) {
    console.error('Erro ao autenticar com a Bullspay:', responseBodyText);
    throw new Error(`Falha na autenticação com a Bullspay (Status: ${response.status}).`);
  }

  const tokenData = JSON.parse(responseBodyText);
  if (!tokenData.access_token) {
    throw new Error('Token de acesso não retornado pela Bullspay.');
  }
  console.log('Token de autenticação obtido com sucesso.');
  return tokenData.access_token;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { amount, robotName, userId } = await req.json();
    console.log(`Iniciando geração de PIX para usuário ${userId} no valor de: R$${amount}`);

    if (!userId) {
      throw new Error('O ID do usuário é obrigatório para buscar os dados do perfil.');
    }

    const bullspayClientId = Deno.env.get('BULLSPAY_CLIENT_ID');
    const bullspaySecret = Deno.env.get('BULLSPAY_SECRET');
    if (!bullspayClientId || !bullspaySecret) {
      throw new Error('As credenciais da Bullspay não estão configuradas no ambiente do Supabase.');
    }

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: req.headers.get('Authorization')! } } }
    );

    const { data: profile, error: profileError } = await supabaseClient
      .from('profiles')
      .select('full_name, email, cpf')
      .eq('user_id', userId)
      .single();

    if (profileError || !profile) {
      console.error('Erro ao buscar perfil do usuário:', profileError);
      throw new Error('Não foi possível encontrar os dados do perfil do usuário.');
    }

    if (!profile.cpf || !profile.full_name || !profile.email) {
      throw new Error('Dados de perfil (Nome, Email, CPF) estão incompletos.');
    }

    const accessToken = await getAuthToken(bullspayClientId, bullspaySecret);

    const requestBody = {
      amount: Math.round(amount * 100),
      description: `Pagamento para ${robotName || 'CryptoAI Miner'}`,
      expiration: 1800,
      customer: {
        name: profile.full_name,
        email: profile.email,
        document: {
          type: "CPF",
          value: profile.cpf.replace(/\D/g, ''),
        }
      }
    };
    console.log('Corpo da requisição para criar cobrança:', JSON.stringify(requestBody));

    const pixResponse = await fetch(PIX_CHARGE_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${accessToken}`,
      },
      body: JSON.stringify(requestBody),
    });

    const pixResponseBodyText = await pixResponse.text();
    console.log("Resposta bruta da Bullspay:", pixResponseBodyText);

    if (!pixResponse.ok) {
      console.error('Erro ao criar cobrança PIX na Bullspay:', pixResponseBodyText);
      try {
        const errorJson = JSON.parse(pixResponseBodyText);
        const errorMessage = errorJson.message || 'Erro desconhecido da Bullspay.';
        throw new Error(`Erro da Bullspay: ${errorMessage}`);
      } catch {
        throw new Error(`Erro ao criar cobrança PIX (Status ${pixResponse.status})`);
      }
    }

    const pixDataResponse = JSON.parse(pixResponseBodyText);

    if (pixDataResponse.success === false || !pixDataResponse.data) {
      console.error("A Bullspay retornou um erro:", pixDataResponse.message, pixDataResponse.errors);
      throw new Error(pixDataResponse.message || "Erro ao processar resposta da Bullspay.");
    }
    
    const pixData = pixDataResponse.data;

    const resultado = {
      pixCode: pixData.brcode || pixData.emv,
      qrCodeUrl: pixData.qr_code_base64 ? `data:image/png;base64,${pixData.qr_code_base64}` : (pixData.qr_code_url || null),
      paymentId: pixData.id,
      amount: amount,
    };

    if (!resultado.pixCode || !resultado.qrCodeUrl) {
      console.error('Dados de PIX ausentes na resposta da Bullspay:', pixData);
      throw new Error('A resposta da Bullspay não incluiu um código PIX ou QR Code válidos.');
    }

    return new Response(JSON.stringify(resultado), { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 });

  } catch (error: any) {
    console.error('Erro geral na função create-pix-payment:', error);
    return new Response(JSON.stringify({ error: error?.message || 'Erro desconhecido ao criar pagamento PIX.' }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 });
  }
});
